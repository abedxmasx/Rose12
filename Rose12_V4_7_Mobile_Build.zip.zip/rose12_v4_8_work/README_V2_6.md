# Rose12 V2.6 — Customer Accounts

- Customer account screen.
- View customer balance, credit invoices, and recorded payments.
- Record a customer payment and reduce the outstanding balance.
- Payment changes queue a customer update for existing sync infrastructure.
- No barcode, no shifts, no cashier management.
- Payment methods remain cash and credit only.

Database version: 7.
