# Rose12 V3.4 — Supervisor Control Center

- Expanded supervisor center with Home, Invoices, and Devices tabs.
- Shows recent audit activity when available.
- Supervisor can refresh dashboard data and activate/deactivate registered devices.
- Keeps sales payment methods limited to cash and credit only.
- No barcode in sales UI, no shifts, no cashier management.
- Fixed duplicated purchase_items quantity declaration in the database creation schema.

Note: Flutter SDK was not available in the build environment, so flutter analyze/build/run were not executed.
