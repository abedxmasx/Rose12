# Rose12 V4.8

- Improved responsive splash/login branding so the logo stays fully visible.
- Added local username/password setup and login persistence.
- Added product image selection from phone storage during add/edit product.
- Product images are copied into app storage and shown in the products list.
- Sales remain name-search only; payment methods remain cash/credit only.
- No shifts/cashier management added.
