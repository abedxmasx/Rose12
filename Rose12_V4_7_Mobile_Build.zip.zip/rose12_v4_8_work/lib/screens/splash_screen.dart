import 'dart:async';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDFEFE), Color(0xFFEAF5FC), Color(0xFFF8F3E8)],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final logoWidth = (constraints.maxWidth * .78).clamp(230.0, 430.0);
              return Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: logoWidth,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: .92),
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: const [BoxShadow(blurRadius: 26, offset: Offset(0, 10), color: Color(0x22000000))],
                        ),
                        child: AspectRatio(
                          aspectRatio: 1030 / 730,
                          child: Image.asset('assets/rose12_logo.png', fit: BoxFit.contain),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text('Sales & Management', style: TextStyle(color: Color(0xFF2C668F), fontSize: 19, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      const Text('إدارة أسهل .. لمستقبل أفضل', style: TextStyle(color: Color(0xFFC79A55), fontSize: 17, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
