import 'package:flutter/material.dart';
import '../database/app_database.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  List<Map<String, dynamic>> rows = [];
  double total = 0;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final r = await AppDatabase.instance.expenses();
    if (!mounted) return;
    setState(() {
      rows = r;
      total = r.fold<double>(
        0,
        (sum, x) => sum + ((x['amount'] as num?)?.toDouble() ?? 0),
      );
    });
  }

  Future<void> add() async {
    final title = TextEditingController();
    final category = TextEditingController();
    final amount = TextEditingController();
    final note = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إضافة مصروف'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: title,
              decoration: const InputDecoration(labelText: 'البيان'),
            ),
            TextField(
              controller: category,
              decoration: const InputDecoration(labelText: 'التصنيف'),
            ),
            TextField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'المبلغ بالدينار'),
            ),
            TextField(
              controller: note,
              decoration: const InputDecoration(labelText: 'ملاحظة'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              double.tryParse(amount.text.replaceAll(',', '.')) != null,
            ),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );

    if (ok == true) {
      await AppDatabase.instance.addExpense(
        title: title.text.trim(),
        category: category.text.trim(),
        amount: double.parse(amount.text.replaceAll(',', '.')),
        note: note.text.trim(),
      );
      await load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المصروفات')),
      floatingActionButton: FloatingActionButton(
        onPressed: add,
        child: const Icon(Icons.add),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: ListTile(
                title: const Text('إجمالي المصروفات'),
                trailing: Text(
                  '${total.toStringAsFixed(2)} د.أ',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
            ...rows.map(
              (x) => Card(
                child: ListTile(
                  title: Text('${x['title']}'),
                  subtitle: Text(
                    '${x['category'] ?? ''} • ${x['created_at']}',
                  ),
                  trailing: Text(
                    '${((x['amount'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
