import 'package:flutter/material.dart';
import '../database/app_database.dart';
import 'invoice_screen.dart';

class SalesHistoryScreen extends StatefulWidget {
  const SalesHistoryScreen({super.key});
  @override
  State<SalesHistoryScreen> createState() => _SalesHistoryScreenState();
}

class _SalesHistoryScreenState extends State<SalesHistoryScreen> {
  List<Map<String, dynamic>> sales = [];
  final search = TextEditingController();
  bool todayOnly = false;
  String paymentFilter = 'الكل';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance.database;
    final data = await db.query('sales', orderBy: 'id DESC');
    if (mounted) setState(() => sales = data);
  }

  List<Map<String, dynamic>> get filtered {
    final q = search.text.trim().toLowerCase();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    return sales.where((s) {
      final invoice = '${s['invoice_number']}'.toLowerCase();
      final customer = '${s['customer_name'] ?? ''}'.toLowerCase();
      final date = '${s['created_at']}'.substring(0, 10);
      final matchesText = q.isEmpty || invoice.contains(q) || customer.contains(q);
      final matchesDate = !todayOnly || date == today;
      final payment = '${s['payment_method'] ?? ''}';
      final matchesPayment = paymentFilter == 'الكل' || payment == paymentFilter;
      return matchesText && matchesDate && matchesPayment;
    }).toList();
  }

  double get visibleTotal => filtered.fold(0, (sum, s) => sum + ((s['total'] as num?)?.toDouble() ?? 0));

  Future<void> _showDetails(Map<String, dynamic> sale) async {
    final db = await AppDatabase.instance.database;
    final items = await db.query('sale_items', where: 'sale_id = ?', whereArgs: [sale['id']]);
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('الفاتورة ${sale['invoice_number']}'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if ((sale['customer_name'] ?? '').toString().isNotEmpty)
                  Align(alignment: Alignment.centerRight, child: Text('العميل: ${sale['customer_name']}')),
                const SizedBox(height: 4),
                Align(alignment: Alignment.centerRight, child: Text('الإجمالي الفرعي: ${(sale['subtotal'] as num).toStringAsFixed(2)} د.أ')),
                Align(alignment: Alignment.centerRight, child: Text('الخصم: ${(sale['discount'] as num?)?.toStringAsFixed(2) ?? '0.00'} د.أ')),
                const SizedBox(height: 8),
                ...items.map((x) => ListTile(
                  dense: true,
                  title: Text('${x['product_name']}'),
                  subtitle: Text('${x['quantity']} × ${(x['unit_price'] as num).toStringAsFixed(2)} د.أ'),
                  trailing: Text('${(x['total'] as num).toStringAsFixed(2)} د.أ'),
                )),
                const Divider(),
                Align(alignment: Alignment.centerRight, child: Text('طريقة الدفع: ${sale['payment_method']}')),
                const SizedBox(height: 4),
                Align(alignment: Alignment.centerRight, child: Text('الإجمالي: ${(sale['total'] as num).toStringAsFixed(2)} د.أ', style: const TextStyle(fontWeight: FontWeight.bold))),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق')),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => InvoiceScreen(sale: sale)));
            },
            icon: const Icon(Icons.receipt_long),
            label: const Text('عرض الفاتورة'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final data = filtered;
    return Scaffold(
      appBar: AppBar(title: const Text('سجل المبيعات')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
              child: TextField(
                controller: search,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  hintText: 'ابحث برقم الفاتورة أو اسم العميل',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Row(
                children: [
                  FilterChip(
                    label: const Text('مبيعات اليوم فقط'),
                    selected: todayOnly,
                    onSelected: (v) => setState(() => todayOnly = v),
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: paymentFilter,
                    items: const [
                      DropdownMenuItem(value: 'الكل', child: Text('كل الدفع')),
                      DropdownMenuItem(value: 'نقدي', child: Text('نقدي')),
                      DropdownMenuItem(value: 'آجل', child: Text('آجل')),
                    ],
                    onChanged: (v) => setState(() => paymentFilter = v ?? 'الكل'),
                  ),
                  const Spacer(),
                  Text('${data.length} فاتورة • ${visibleTotal.toStringAsFixed(2)} د.أ', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Expanded(
              child: data.isEmpty
                  ? const Center(child: Text('لا توجد فواتير مطابقة'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(14),
                      itemCount: data.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final s = data[i];
                        return Card(
                          child: ListTile(
                            onTap: () => _showDetails(s),
                            leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
                            title: Text('${s['invoice_number']}'),
                            subtitle: Text('${s['payment_method']} • ${s['created_at']}'),
                            trailing: Text('${(s['total'] as num).toStringAsFixed(2)} د.أ', style: const TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
