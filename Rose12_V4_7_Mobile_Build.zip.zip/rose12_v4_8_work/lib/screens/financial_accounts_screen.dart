import 'package:flutter/material.dart';
import '../database/app_database.dart';

class FinancialAccountsScreen extends StatefulWidget {
  const FinancialAccountsScreen({super.key});
  @override State<FinancialAccountsScreen> createState() => _FinancialAccountsScreenState();
}

class _FinancialAccountsScreenState extends State<FinancialAccountsScreen> {
  int tab = 0;
  bool loading = true;
  List<Map<String,dynamic>> customers = [], suppliers = [];
  Map<String,double> totals = {'customer_debt':0,'supplier_debt':0};

  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async {
    setState(() => loading = true);
    final db = AppDatabase.instance;
    final c = await db.customers();
    final s = await db.suppliers();
    final t = await db.accountsTotals();
    if (!mounted) return;
    setState(() { customers=c; suppliers=s; totals=t; loading=false; });
  }
  String money(num v) => '${v.toDouble().toStringAsFixed(2)} د.أ';

  Future<void> _customer(Map<String,dynamic> c) async {
    final id=c['id'] as int;
    final sales=await AppDatabase.instance.customerSales(id);
    final payments=await AppDatabase.instance.customerPayments(id);
    final balance=(c['balance'] as num?)?.toDouble() ?? 0;
    if(!mounted)return;
    Navigator.push(context, MaterialPageRoute(builder: (_)=>_LedgerScreen(title:'حساب ${c['name']}', balance:balance, entries:[
      ...sales.where((x)=>x['payment_method']=='آجل').map((x)=>{'date':x['created_at'],'title':'فاتورة ${x['invoice_number']}','debit':(x['total'] as num).toDouble(),'credit':0.0}),
      ...payments.map((x)=>{'date':x['created_at'],'title':'دفعة${(x['note']??'').toString().isEmpty?'':' • ${x['note']}'}','debit':0.0,'credit':(x['amount'] as num).toDouble()}),
    ])));
  }

  Future<void> _supplier(Map<String,dynamic> s) async {
    final id=s['id'] as int;
    final purchases=await AppDatabase.instance.supplierPurchases(id);
    final payments=await AppDatabase.instance.supplierPayments(id);
    final balance=(s['balance'] as num?)?.toDouble() ?? 0;
    if(!mounted)return;
    Navigator.push(context, MaterialPageRoute(builder: (_)=>_LedgerScreen(title:'حساب ${s['name']}', balance:balance, entries:[
      ...purchases.where((x)=>((x['total'] as num).toDouble()-(x['paid_amount'] as num).toDouble())>0).map((x)=>{'date':x['created_at'],'title':'فاتورة شراء ${x['invoice_number']}','debit':((x['total'] as num).toDouble()-(x['paid_amount'] as num).toDouble()),'credit':0.0}),
      ...payments.map((x)=>{'date':x['created_at'],'title':'دفعة${(x['note']??'').toString().isEmpty?'':' • ${x['note']}'}','debit':0.0,'credit':(x['amount'] as num).toDouble()}),
    ])));
  }

  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    appBar:AppBar(title:const Text('الحسابات المالية')),
    body:RefreshIndicator(onRefresh:_load,child:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(12),children:[
      Row(children:[Expanded(child:_summary('ديون العملاء',totals['customer_debt']??0,Icons.people_alt_outlined)),const SizedBox(width:10),Expanded(child:_summary('مستحق للموردين',totals['supplier_debt']??0,Icons.local_shipping_outlined))]),
      const SizedBox(height:12),
      SegmentedButton<int>(segments:const [ButtonSegment(value:0,label:Text('العملاء'),icon:Icon(Icons.people_alt_outlined)),ButtonSegment(value:1,label:Text('الموردون'),icon:Icon(Icons.local_shipping_outlined))],selected:{tab},onSelectionChanged:(v){setState(()=>tab=v.first);}),
      const SizedBox(height:12),
      if(tab==0)...customers.map((c)=>Card(child:ListTile(onTap:()=>_customer(c),title:Text('${c['name']}'),subtitle:Text('${c['phone']??''}\nالرصيد: ${money((c['balance'] as num?)??0)}'),isThreeLine:true,trailing:const Icon(Icons.chevron_left)))),
      if(tab==1)...suppliers.map((s)=>Card(child:ListTile(onTap:()=>_supplier(s),title:Text('${s['name']}'),subtitle:Text('${s['phone']??''}\nالرصيد: ${money((s['balance'] as num?)??0)}'),isThreeLine:true,trailing:const Icon(Icons.chevron_left)))),
      if((tab==0?customers:suppliers).isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Center(child:Text('لا توجد حسابات')))),
    ])),
  ));
  Widget _summary(String title,double value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Icon(icon),const SizedBox(height:6),Text(money(value),style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)),Text(title,style:const TextStyle(color:Colors.grey))])));
}

class _LedgerScreen extends StatelessWidget {
  final String title; final double balance; final List<Map<String,dynamic>> entries;
  const _LedgerScreen({required this.title,required this.balance,required this.entries});
  String money(num v)=>'${v.toDouble().toStringAsFixed(2)} د.أ';
  @override Widget build(BuildContext context){
    final sorted=[...entries]..sort((a,b)=>b['date'].toString().compareTo(a['date'].toString()));
    return Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:Text(title)),body:ListView(padding:const EdgeInsets.all(12),children:[
      Card(child:ListTile(title:const Text('الرصيد الحالي'),trailing:Text(money(balance),style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:balance>0?Colors.red:Colors.green)))),
      const SizedBox(height:8),
      if(sorted.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Center(child:Text('لا توجد حركة على الحساب')))),
      ...sorted.map((e)=>Card(child:ListTile(title:Text(e['title'].toString()),subtitle:Text(e['date'].toString().substring(0,10)),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[if((e['debit'] as num)>0)Text('مدين ${money(e['debit'])}',style:const TextStyle(fontWeight:FontWeight.bold)),if((e['credit'] as num)>0)Text('دائن ${money(e['credit'])}',style:const TextStyle(fontWeight:FontWeight.bold))])))),
    ])));
  }
}
