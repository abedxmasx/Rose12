import 'package:flutter/material.dart';
import '../database/app_database.dart';

class ProductPriceHistoryScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  const ProductPriceHistoryScreen({super.key, required this.product});
  @override
  State<ProductPriceHistoryScreen> createState() => _ProductPriceHistoryScreenState();
}

class _ProductPriceHistoryScreenState extends State<ProductPriceHistoryScreen> {
  List<Map<String, dynamic>> rows = [];
  bool loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final r = await AppDatabase.instance.productPriceHistory(widget.product['id'] as int);
    if (mounted) setState(() { rows = r; loading = false; });
  }

  String money(dynamic v) => '${((v as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ';
  String date(dynamic v) => '${v ?? ''}'.replaceFirst('T', ' ').split('.').first;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('سجل أسعار ${widget.product['name']}')),
    body: Directionality(textDirection: TextDirection.rtl, child: loading
      ? const Center(child: CircularProgressIndicator())
      : RefreshIndicator(onRefresh: _load, child: rows.isEmpty
        ? ListView(children: const [SizedBox(height: 180), Center(child: Text('لا توجد تغييرات مسجلة على الأسعار'))])
        : ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (_, i) {
            final r = rows[i];
            return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(date(r['changed_at']), style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              _line('التكلفة', r['old_cost_price'], r['new_cost_price']),
              _line('البيع', r['old_sale_price'], r['new_sale_price']),
              _line('الجملة', r['old_wholesale_price'], r['new_wholesale_price']),
            ])));
          }),)),
  );

  Widget _line(String label, dynamic oldValue, dynamic newValue) => Padding(
    padding: const EdgeInsets.only(bottom: 5),
    child: Row(children: [Expanded(child: Text(label)), Text(money(oldValue)), const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.arrow_back, size: 16)), Text(money(newValue), style: const TextStyle(fontWeight: FontWeight.bold))]),
  );
}
