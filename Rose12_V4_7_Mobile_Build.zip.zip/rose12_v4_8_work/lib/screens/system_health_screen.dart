import 'package:flutter/material.dart';
import '../database/app_database.dart';
import '../services/sync_service.dart';

class SystemHealthScreen extends StatefulWidget {
  const SystemHealthScreen({super.key});
  @override
  State<SystemHealthScreen> createState() => _SystemHealthScreenState();
}

class _SystemHealthScreenState extends State<SystemHealthScreen> {
  bool loading = true;
  int pending = 0;
  int failed = 0;
  int auditCount = 0;
  List<Map<String, dynamic>> logs = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final db = await AppDatabase.instance.database;
    final status = await SyncService.instance.status();
    final rows = await db.query('audit_logs', orderBy: 'id DESC', limit: 100);
    final count = (await db.rawQuery('SELECT COUNT(*) c FROM audit_logs')).first['c'] as int? ?? 0;
    if (!mounted) return;
    setState(() {
      pending = status['pending'] as int? ?? 0;
      failed = status['failed'] as int? ?? 0;
      logs = rows;
      auditCount = count;
      loading = false;
    });
  }

  String _date(String? value) {
    if (value == null || value.isEmpty) return '-';
    final d = DateTime.tryParse(value);
    if (d == null) return value;
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('صحة النظام وسجل العمليات'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            if (loading) const LinearProgressIndicator(),
            const Text('حالة النظام', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _stat('بانتظار المزامنة', '$pending', Icons.cloud_upload_outlined)),
              const SizedBox(width: 10),
              Expanded(child: _stat('فشل المزامنة', '$failed', Icons.error_outline)),
            ]),
            const SizedBox(height: 10),
            Card(child: ListTile(leading: const Icon(Icons.history), title: const Text('سجل العمليات'), subtitle: Text('إجمالي السجلات: $auditCount'))),
            const SizedBox(height: 14),
            const Text('آخر العمليات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (logs.isEmpty) const Card(child: ListTile(title: Text('لا توجد عمليات مسجلة بعد'))),
            ...logs.map((x) => Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.receipt_long, size: 18)),
                title: Text('${x['action'] ?? 'عملية'}'),
                subtitle: Text('${x['entity_type'] ?? ''}  •  ${x['details'] ?? ''}\n${_date(x['created_at']?.toString())}'),
                isThreeLine: true,
              ),
            )),
          ],
        ),
      ),
    ),
  );

  Widget _stat(String title, String value, IconData icon) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(children: [Icon(icon, color: const Color(0xFF2C668F)), const SizedBox(height: 7), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))]),
    ),
  );
}
