import 'dart:io';
import 'package:flutter/material.dart';
import '../services/backup_service.dart';

class BackupRestoreScreen extends StatefulWidget {
  const BackupRestoreScreen({super.key});
  @override State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  bool busy = false;
  String status = 'جاهز';
  File? lastBackup;
  List<File> backups = [];

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try { final items = await BackupService.instance.listBackups(); if (mounted) setState(() => backups = items); } catch (_) {}
  }

  Future<void> backup() async {
    setState(() { busy = true; status = 'جاري إنشاء النسخة والتحقق منها...'; });
    try {
      final file = await BackupService.instance.createBackup();
      lastBackup = file;
      status = 'تم إنشاء نسخة سليمة بنجاح';
      await _load();
    } catch (e) { status = 'فشل النسخ: $e'; }
    if (mounted) setState(() => busy = false);
  }

  Future<void> share(File file) async { try { await BackupService.instance.shareBackup(file); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'))); } }

  Future<void> restore() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('استعادة قاعدة البيانات'),
      content: const Text('سيتم أولاً إنشاء نسخة أمان تلقائية من البيانات الحالية، ثم استبدالها بالنسخة المختارة.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('متابعة'))],
    ));
    if (ok != true) return;
    setState(() { busy = true; status = 'اختر ملف النسخة الاحتياطية...'; });
    try {
      final file = await BackupService.instance.pickBackup();
      if (file == null) status = 'تم إلغاء الاستعادة';
      else { await BackupService.instance.restoreBackup(file); status = 'تمت الاستعادة وإنشاء نسخة أمان قبلها'; await _load(); }
    } catch (e) { status = 'فشل الاستعادة: $e'; }
    if (mounted) setState(() => busy = false);
  }

  Future<void> delete(File file) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف النسخة؟'), content: Text(file.path.split(Platform.pathSeparator).last),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))],
    ));
    if (ok == true) { await BackupService.instance.deleteBackup(file); await _load(); }
  }

  String size(File f) { final b = f.lengthSync(); return '${(b / 1024).toStringAsFixed(1)} KB'; }
  String name(File f) => f.path.split(Platform.pathSeparator).last;

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('النسخ الاحتياطي والاستعادة')),
    body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.verified_user_rounded, size: 58),
        const SizedBox(height: 10),
        const Text('حماية بيانات Rose12', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('كل نسخة جديدة يتم فحصها للتأكد من أنها قاعدة SQLite سليمة.', textAlign: TextAlign.center),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: busy ? null : backup, icon: const Icon(Icons.save_alt), label: const Text('إنشاء نسخة احتياطية الآن')),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: busy ? null : restore, icon: const Icon(Icons.restore), label: const Text('استعادة نسخة احتياطية')),
        const SizedBox(height: 14), Text(status, textAlign: TextAlign.center),
      ]))),
      const SizedBox(height: 14),
      const Text('النسخ المحفوظة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (backups.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('لا توجد نسخ محفوظة بعد.'))),
      ...backups.map((file) => Card(child: ListTile(
        leading: const Icon(Icons.storage_rounded), title: Text(name(file)), subtitle: Text('${size(file)} • ${file.statSync().modified}'),
        trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'share') share(file); if (v == 'delete') delete(file); }, itemBuilder: (_) => const [PopupMenuItem(value: 'share', child: Text('مشاركة')), PopupMenuItem(value: 'delete', child: Text('حذف'))]),
      ))),
      const SizedBox(height: 12),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('عند الاستعادة، ينشئ النظام نسخة أمان تلقائية من قاعدة البيانات الحالية قبل الاستبدال.'))),
    ])),
  );
}
