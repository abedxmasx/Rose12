import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';

class EditProductScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  const EditProductScreen({super.key, required this.product});
  @override
  State<EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  late final TextEditingController name;
  late final TextEditingController category;
  late final TextEditingController unit;
  late final TextEditingController cost;
  late final TextEditingController price;
  late final TextEditingController wholesale;
  late final TextEditingController minStock;
  String? imagePath;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    name = TextEditingController(text: '${p['name'] ?? ''}');
    category = TextEditingController(text: '${p['category'] ?? ''}');
    unit = TextEditingController(text: '${p['unit'] ?? 'قطعة'}');
    cost = TextEditingController(text: '${p['cost_price'] ?? 0}');
    price = TextEditingController(text: '${p['sale_price'] ?? 0}');
    wholesale = TextEditingController(text: '${p['wholesale_price'] ?? 0}');
    minStock = TextEditingController(text: '${p['min_stock'] ?? 0}');
    imagePath = (p['image_path'] as String?)?.trim().isEmpty == true ? null : p['image_path'] as String?;
  }

  @override
  void dispose() { for (final c in [name, category, unit, cost, price, wholesale, minStock]) { c.dispose(); } super.dispose(); }

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (result == null || result.files.single.bytes == null) return;
    final ext = (result.files.single.extension ?? 'jpg').toLowerCase();
    final dir = await getApplicationDocumentsDirectory();
    final imageDir = Directory('${dir.path}/product_images');
    await imageDir.create(recursive: true);
    final path = '${imageDir.path}/product_${DateTime.now().microsecondsSinceEpoch}.$ext';
    await File(path).writeAsBytes(result.files.single.bytes!, flush: true);
    if (mounted) setState(() => imagePath = path);
  }

  Future<void> _save() async {
    if (name.text.trim().isEmpty || double.tryParse(price.text) == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اسم المنتج وسعر البيع مطلوبان')));
      return;
    }
    setState(() => saving = true);
    await AppDatabase.instance.updateProduct(widget.product['id'] as int, {
      'name': name.text.trim(),
      'category': category.text.trim(),
      'unit': unit.text.trim().isEmpty ? 'قطعة' : unit.text.trim(),
      'cost_price': double.tryParse(cost.text) ?? 0,
      'sale_price': double.tryParse(price.text) ?? 0,
      'wholesale_price': double.tryParse(wholesale.text) ?? 0,
      'min_stock': double.tryParse(minStock.text) ?? 0,
      'image_path': imagePath,
    });
    if (mounted) Navigator.pop(context, true);
    if (mounted) setState(() => saving = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تعديل المنتج')),
    body: Directionality(textDirection: TextDirection.rtl, child: ListView(padding: const EdgeInsets.all(16), children: [
      _imagePicker(),
      const SizedBox(height: 14),
      _field(name, 'اسم المنتج', Icons.inventory_2_outlined),
      _field(category, 'التصنيف', Icons.category_outlined),
      _field(unit, 'الوحدة', Icons.straighten_outlined),
      Row(children: [
        Expanded(child: _field(cost, 'سعر التكلفة', Icons.price_change_outlined, number: true)),
        const SizedBox(width: 10),
        Expanded(child: _field(price, 'سعر البيع', Icons.sell_outlined, number: true)),
      ]),
      _field(wholesale, 'سعر الجملة', Icons.storefront_outlined, number: true),
      _field(minStock, 'حد إعادة الطلب', Icons.warning_amber_outlined, number: true),
      const SizedBox(height: 8),
      Text('المخزون الحالي: ${widget.product['quantity']} ${widget.product['unit'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      SizedBox(height: 52, child: FilledButton.icon(onPressed: saving ? null : _save, icon: saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined), label: Text(saving ? 'جاري الحفظ...' : 'حفظ التعديلات'))),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () => Navigator.pushNamed(context, '/product-price-history', arguments: widget.product),
        icon: const Icon(Icons.history),
        label: const Text('سجل تغييرات الأسعار'),
      ),
    ])),
  );

  Widget _imagePicker() {
    final hasImage = imagePath != null && File(imagePath!).existsSync();
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _pickImage,
        child: SizedBox(
          height: 190,
          child: hasImage
              ? Stack(fit: StackFit.expand, children: [
                  Image.file(File(imagePath!), fit: BoxFit.contain),
                  Positioned(bottom: 8, left: 8, child: FilledButton.icon(onPressed: _pickImage, icon: const Icon(Icons.edit, size: 18), label: const Text('تغيير الصورة'))),
                ])
              : const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.add_photo_alternate_outlined, size: 54),
                  SizedBox(height: 10),
                  Text('إضافة صورة المنتج', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('اضغط لاختيار صورة من الهاتف'),
                ]),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool number = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon))),
  );
}
