import 'package:flutter/material.dart';
import '../services/supervisor_service.dart';

class DeviceManagementScreen extends StatefulWidget {
  const DeviceManagementScreen({super.key});
  @override
  State<DeviceManagementScreen> createState() => _DeviceManagementScreenState();
}

class _DeviceManagementScreenState extends State<DeviceManagementScreen> {
  List<Map<String, dynamic>> devices = [];
  List<Map<String, dynamic>> audit = [];
  bool busy = true;

  Future<void> load() async {
    setState(() => busy = true);
    try {
      final d = await SupervisorService.instance.devices();
      final a = await SupervisorService.instance.auditLogs();
      if (mounted) setState(() { devices = d; audit = a; busy = false; });
    } catch (_) {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> toggle(Map<String, dynamic> d) async {
    final ok = await SupervisorService.instance.setDeviceActive(
      d['id'] as int, (d['active'] as int) == 0,
    );
    if (ok) load();
  }

  Future<void> addDevice() async {
    final key = TextEditingController();
    final name = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('إضافة جهاز'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الجهاز')),
        const SizedBox(height: 10),
        TextField(controller: key, decoration: const InputDecoration(labelText: 'Device Key')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          if (key.text.trim().isEmpty || name.text.trim().isEmpty) return;
          final ok = await SupervisorService.instance.registerDevice(key.text.trim(), name.text.trim());
          if (c.mounted) Navigator.pop(c, ok);
        }, child: const Text('حفظ')),
      ],
    ));
    if (result == true) load();
  }

  @override
  void initState() { super.initState(); load(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إدارة الأجهزة'), actions: [
      IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
      IconButton(onPressed: addDevice, icon: const Icon(Icons.add_to_queue)),
    ]),
    body: Directionality(textDirection: TextDirection.rtl, child: RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        if (busy) const LinearProgressIndicator(),
        const Text('الأجهزة المسجلة', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...devices.map((d) => Card(child: ListTile(
          leading: CircleAvatar(child: Icon((d['active'] as int) == 1 ? Icons.devices : Icons.block)),
          title: Text(d['name']?.toString() ?? ''),
          subtitle: Text('${d['device_key']}\nآخر تسجيل: ${d['last_seen'] ?? '—'}'),
          isThreeLine: true,
          trailing: Switch(value: (d['active'] as int) == 1, onChanged: (_) => toggle(d)),
        ))),
        const SizedBox(height: 22),
        const Text('آخر سجل تدقيق', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...audit.take(30).map((x) => Card(child: ListTile(
          leading: const Icon(Icons.history),
          title: Text('${x['action']} • ${x['entity_type'] ?? ''}'),
          subtitle: Text('${x['username'] ?? 'device'}\n${x['created_at'] ?? ''}\n${x['details'] ?? ''}'),
          isThreeLine: true,
        ))),
      ]),
    )),
  );
}
