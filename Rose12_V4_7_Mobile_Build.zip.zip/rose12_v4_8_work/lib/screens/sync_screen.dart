import 'package:flutter/material.dart';
import '../services/sync_service.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});
  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  int pending = 0;
  int failed = 0;
  bool configured = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final s = await SyncService.instance.status();
    if (!mounted) return;
    setState(() {
      pending = s['pending'] as int;
      failed = s['failed'] as int;
      configured = s['configured'] as bool;
    });
  }

  Future<void> _sync() async {
    await SyncService.instance.syncNow();
    await _refresh();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت محاولة المزامنة وحفظ النتيجة محلياً.')));
  }

  Future<void> _retry() async {
    await SyncService.instance.retryFailed();
    await _refresh();
  }

  Future<void> _prepare() async {
    final payload = await SyncService.instance.buildPendingPayload();
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('جاهز للترحيل'),
        content: Text(
          'عدد الفواتير الجاهزة: ${payload.length}\n\n'
          'الفواتير محفوظة محلياً ولا تضيع عند انقطاع الإنترنت.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('موافق'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الترحيل والمزامنة')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.cloud_upload_outlined),
                title: const Text('فواتير بانتظار الترحيل'),
                trailing: Text('$pending',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.error_outline),
                title: const Text('محاولات فاشلة'),
                trailing: Text('$failed',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(configured ? Icons.cloud_done : Icons.cloud_off),
                title: const Text('خادم المشرفين'),
                subtitle: Text(configured ? 'تم إعداد عنوان الخادم' : 'لم يتم ربط الخادم بعد'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _sync,
                icon: const Icon(Icons.sync),
                label: const Text('مزامنة الآن'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 48,
              child: OutlinedButton.icon(
                onPressed: failed == 0 ? null : _retry,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة المحاولات الفاشلة'),
              ),
            ),
            const SizedBox(height: 12),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'هذه المرحلة جهزت طبقة المزامنة وقائمة الترحيل. '
                  'الخطوة التالية هي ربط API آمن بالمشرفين مع إعادة المحاولة ومنع تكرار الفاتورة.',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
