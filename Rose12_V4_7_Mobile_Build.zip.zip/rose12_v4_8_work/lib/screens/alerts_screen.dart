import 'package:flutter/material.dart';
import '../database/app_database.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});
  @override State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertItem {
  final String title, detail;
  final IconData icon;
  final Color color;
  final String? route;
  _AlertItem(this.title, this.detail, this.icon, this.color, this.route);
}

class _AlertsScreenState extends State<AlertsScreen> {
  bool loading = true;
  List<_AlertItem> alerts = [];

  @override void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    final db = await AppDatabase.instance.database;
    final low = await AppDatabase.instance.lowStockProducts();
    final pending = await AppDatabase.instance.pendingSyncCount();
    final failed = await db.rawQuery("SELECT COUNT(*) c FROM sync_queue WHERE status = 'failed'");
    final customer = await db.rawQuery("SELECT COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END),0) total FROM customers");
    final supplier = await db.rawQuery("SELECT COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END),0) total FROM suppliers");
    final backup = await db.rawQuery("SELECT MAX(created_at) last_backup FROM audit_logs WHERE action = 'backup_created'");
    final list = <_AlertItem>[];
    if (low.isNotEmpty) list.add(_AlertItem('مخزون منخفض', '${low.length} منتج يحتاج مراجعة أو إعادة شراء.', Icons.warning_amber_rounded, Colors.orange, '/inventory'));
    final f = (failed.first['c'] as num?)?.toInt() ?? 0;
    if (f > 0) list.add(_AlertItem('مزامنة فاشلة', '$f عملية تحتاج إعادة المحاولة.', Icons.sync_problem, Colors.red, '/sync'));
    if (pending > 0) list.add(_AlertItem('عمليات بانتظار المزامنة', '$pending عملية محفوظة محليًا بانتظار المزامنة.', Icons.cloud_upload_outlined, Colors.blue, '/sync'));
    final cd = (customer.first['total'] as num?)?.toDouble() ?? 0;
    if (cd > 0) list.add(_AlertItem('ديون العملاء', '${cd.toStringAsFixed(2)} د.أ مستحقة من العملاء.', Icons.people_alt_outlined, Colors.deepPurple, '/financial-accounts'));
    final sd = (supplier.first['total'] as num?)?.toDouble() ?? 0;
    if (sd > 0) list.add(_AlertItem('مستحقات الموردين', '${sd.toStringAsFixed(2)} د.أ مستحقة للموردين.', Icons.local_shipping_outlined, Colors.teal, '/financial-accounts'));
    if (backup.first['last_backup'] == null) list.add(_AlertItem('لا توجد نسخة احتياطية مسجلة', 'أنشئ نسخة احتياطية لحماية بيانات Rose12.', Icons.backup_outlined, Colors.redAccent, '/backup-restore'));
    if (mounted) setState(() { alerts = list; loading = false; });
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('التنبيهات والمهام'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
    body: Directionality(textDirection: TextDirection.rtl, child: RefreshIndicator(onRefresh: load, child: loading
      ? ListView(children: const [SizedBox(height: 260), Center(child: CircularProgressIndicator())])
      : alerts.isEmpty
        ? ListView(children: const [SizedBox(height: 180), Icon(Icons.check_circle_outline, size: 64, color: Colors.green), SizedBox(height: 12), Center(child: Text('لا توجد تنبيهات حالية', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), SizedBox(height: 6), Center(child: Text('النظام لا يحتوي على مهام تحتاج تدخلاً الآن.'))])
        : ListView(padding: const EdgeInsets.all(16), children: [
            Text('${alerts.length} تنبيه', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...alerts.map((a) => Card(child: ListTile(
              leading: CircleAvatar(backgroundColor: a.color.withOpacity(.12), child: Icon(a.icon, color: a.color)),
              title: Text(a.title, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(a.detail)),
              trailing: a.route == null ? null : const Icon(Icons.chevron_left),
              onTap: a.route == null ? null : () => Navigator.pushNamed(context, a.route!),
            )))
          ]))));
}
