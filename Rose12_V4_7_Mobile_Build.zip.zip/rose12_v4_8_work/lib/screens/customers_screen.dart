import 'package:flutter/material.dart';
import '../database/app_database.dart';
import 'customer_account_screen.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  List<Map<String, dynamic>> rows = [];
  String query = '';
  bool loading = true;

  @override void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    final r = await AppDatabase.instance.customers();
    if (!mounted) return;
    setState(() { rows = r; loading = false; });
  }

  Future<void> add() async {
    final n = TextEditingController(), p = TextEditingController(), a = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('إضافة عميل'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'اسم العميل')),
        const SizedBox(height: 10),
        TextField(controller: p, keyboardType: TextInputType.phone, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'الهاتف')),
        const SizedBox(height: 10),
        TextField(controller: a, decoration: const InputDecoration(labelText: 'العنوان')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, n.text.trim().isNotEmpty), child: const Text('حفظ')),
      ],
    ));
    if (ok == true) { await AppDatabase.instance.addCustomer(name: n.text.trim(), phone: p.text.trim(), address: a.text.trim()); await load(); }
  }

  List<Map<String, dynamic>> get filtered {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return rows;
    return rows.where((x) => '${x['name'] ?? ''}'.toLowerCase().contains(q) || '${x['phone'] ?? ''}'.toLowerCase().contains(q)).toList();
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('العملاء'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
    floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.person_add)),
    body: Directionality(textDirection: TextDirection.rtl, child: RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(12), children: [
        TextField(onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث باسم العميل أو الهاتف'),),
        const SizedBox(height: 12),
        if (loading) const LinearProgressIndicator(),
        if (!loading && filtered.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا يوجد عملاء'))),
        ...filtered.map((x) {
          final balance = (x['balance'] as num?)?.toDouble() ?? 0;
          return Card(child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text('${x['name']}'),
            subtitle: Text('${x['phone'] ?? ''}${(x['address'] ?? '').toString().isEmpty ? '' : '\n${x['address']}'}'),
            isThreeLine: (x['address'] ?? '').toString().isNotEmpty,
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${balance.toStringAsFixed(2)} د.أ', style: TextStyle(fontWeight: FontWeight.bold, color: balance > 0 ? Colors.red.shade700 : Colors.green.shade700)),
              const Text('فتح الحساب', style: TextStyle(fontSize: 11)),
            ]),
            onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerAccountScreen(customer: x))); await load(); },
          ));
        }),
      ],
    ))),
  );
}
