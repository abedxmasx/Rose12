import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController();
  final password = TextEditingController();
  bool loading = true;
  bool hasAccount = false;
  bool obscure = true;

  @override
  void initState() {
    super.initState();
    _loadAccount();
  }

  Future<void> _loadAccount() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('rose12_username');
    if (saved != null && saved.isNotEmpty) username.text = saved;
    if (mounted) setState(() { hasAccount = saved != null && saved.isNotEmpty; loading = false; });
  }

  Future<void> _login() async {
    final u = username.text.trim();
    final pass = password.text;
    if (u.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم المستخدم وكلمة المرور')));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('rose12_username');
    final savedPass = prefs.getString('rose12_password');
    if (savedUser == null || savedPass == null) {
      await prefs.setString('rose12_username', u);
      await prefs.setString('rose12_password', pass);
    } else if (savedUser != u || savedPass != pass) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اسم المستخدم أو كلمة المرور غير صحيحة')));
      return;
    }
    if (mounted) Navigator.pushReplacementNamed(context, '/dashboard');
  }

  @override
  void dispose() { username.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFDFEFE), Color(0xFFEAF5FC), Color(0xFFF8F3E8)])),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .92), borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(blurRadius: 24, offset: Offset(0, 8), color: Color(0x22000000))]),
                    child: Image.asset('assets/rose12_logo.png', width: 300, fit: BoxFit.contain),
                  ),
                  const SizedBox(height: 18),
                  const Text('مرحباً بك في Rose12', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xFF2C668F))),
                  const SizedBox(height: 7),
                  Text(loading ? 'جاري التحضير...' : (hasAccount ? 'سجّل الدخول بحسابك' : 'أنشئ اسم المستخدم الخاص بك لأول مرة'), style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 24),
                  TextField(controller: username, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline))),
                  const SizedBox(height: 14),
                  TextField(controller: password, obscureText: obscure, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined)))),
                  const SizedBox(height: 22),
                  SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : _login, child: Text(hasAccount ? 'دخول' : 'إنشاء الحساب والدخول'))),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
