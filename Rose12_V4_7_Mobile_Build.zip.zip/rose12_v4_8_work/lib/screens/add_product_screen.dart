import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final name = TextEditingController();
  final price = TextEditingController();
  final cost = TextEditingController();
  final quantity = TextEditingController();
  String? imagePath;
  bool saving = false;

  @override
  void dispose() {
    name.dispose();
    price.dispose();
    cost.dispose();
    quantity.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result == null || result.files.single.bytes == null) return;
    final ext = (result.files.single.extension ?? 'jpg').toLowerCase();
    final dir = await getApplicationDocumentsDirectory();
    final imageDir = Directory('${dir.path}/product_images');
    await imageDir.create(recursive: true);
    final path = '${imageDir.path}/product_${DateTime.now().microsecondsSinceEpoch}.$ext';
    await File(path).writeAsBytes(result.files.single.bytes!, flush: true);
    if (mounted) setState(() => imagePath = path);
  }

  Future<void> _save() async {
    if (name.text.trim().isEmpty || price.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اسم المنتج وسعر البيع مطلوبان')),
      );
      return;
    }
    setState(() => saving = true);
    try {
      await AppDatabase.instance.addProduct({
        'name': name.text.trim(),
        'sku': '',
        'barcode': '',
        'category': '',
        'unit': 'قطعة',
        'cost_price': double.tryParse(cost.text) ?? 0,
        'sale_price': double.tryParse(price.text) ?? 0,
        'wholesale_price': 0,
        'quantity': double.tryParse(quantity.text) ?? 0,
        'min_stock': 0,
        'image_path': imagePath,
        'created_at': DateTime.now().toIso8601String(),
      });
      if (mounted) Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة منتج')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _imagePicker(),
            const SizedBox(height: 14),
            _field(name, 'اسم المنتج', Icons.inventory_2_outlined),
            Row(children: [
              Expanded(child: _field(cost, 'سعر التكلفة', Icons.price_change_outlined, number: true)),
              const SizedBox(width: 10),
              Expanded(child: _field(price, 'سعر البيع', Icons.sell_outlined, number: true)),
            ]),
            _field(quantity, 'الكمية الافتتاحية', Icons.numbers, number: true),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: saving ? null : _save,
                icon: saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined),
                label: Text(saving ? 'جاري الحفظ...' : 'حفظ المنتج'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _imagePicker() {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _pickImage,
        child: SizedBox(
          height: 190,
          child: imagePath == null
              ? const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_photo_alternate_outlined, size: 54),
                    SizedBox(height: 10),
                    Text('إضافة صورة المنتج', style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text('اضغط لاختيار صورة من الهاتف'),
                  ],
                )
              : Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(File(imagePath!), fit: BoxFit.contain),
                    Positioned(
                      bottom: 8,
                      left: 8,
                      child: FilledButton.icon(
                        onPressed: _pickImage,
                        icon: const Icon(Icons.edit, size: 18),
                        label: const Text('تغيير الصورة'),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool number = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        keyboardType: number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      ),
    );
  }
}
