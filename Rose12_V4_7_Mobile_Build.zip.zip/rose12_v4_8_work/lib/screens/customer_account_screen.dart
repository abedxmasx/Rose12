import 'package:flutter/material.dart';
import '../database/app_database.dart';

class CustomerAccountScreen extends StatefulWidget {
  final Map<String, dynamic> customer;
  const CustomerAccountScreen({super.key, required this.customer});
  @override State<CustomerAccountScreen> createState() => _CustomerAccountScreenState();
}

class _CustomerAccountScreenState extends State<CustomerAccountScreen> {
  List<Map<String, dynamic>> sales = [];
  List<Map<String, dynamic>> payments = [];
  double balance = 0;
  bool loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final id = widget.customer['id'] as int;
    final c = await AppDatabase.instance.customers();
    final found = c.where((x) => x['id'] == id).toList();
    final s = await AppDatabase.instance.customerSales(id);
    final p = await AppDatabase.instance.customerPayments(id);
    if (!mounted) return;
    setState(() { balance = found.isEmpty ? 0 : (found.first['balance'] as num).toDouble(); sales = s; payments = p; loading = false; });
  }

  Future<void> _payment() async {
    final amount = TextEditingController();
    final note = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('تسجيل دفعة'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('الرصيد المستحق: ${balance.toStringAsFixed(2)} د.أ'),
        const SizedBox(height: 10),
        TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'مبلغ الدفعة', suffixText: 'د.أ')),
        const SizedBox(height: 8),
        TextField(controller: note, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ'))],
    ));
    if (ok != true) return;
    final v = double.tryParse(amount.text.replaceAll(',', '.')) ?? 0;
    if (v <= 0) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل مبلغاً صحيحاً'))); return; }
    try {
      await AppDatabase.instance.addCustomerPayment(customerId: widget.customer['id'] as int, amount: v, note: note.text.trim().isEmpty ? null : note.text.trim());
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('حساب ${widget.customer['name']}')),
    body: Directionality(textDirection: TextDirection.rtl, child: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          Text('${widget.customer['name']}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          if ((widget.customer['phone'] ?? '').toString().isNotEmpty) Text('${widget.customer['phone']}'),
          const SizedBox(height: 12),
          Text('الرصيد المستحق', style: TextStyle(color: Colors.grey.shade700)),
          Text('${balance.toStringAsFixed(2)} د.أ', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: balance > 0 ? Colors.red.shade700 : Colors.green.shade700)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: balance > 0 ? _payment : null, icon: const Icon(Icons.payments_outlined), label: const Text('تسجيل دفعة'))),
        ]))),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الفواتير الآجلة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), Text('${sales.length} فاتورة')]),
        ...sales.map((s) => ListTile(leading: const Icon(Icons.receipt_long), title: Text('فاتورة ${s['invoice_number']}'), subtitle: Text('${s['created_at'].toString().substring(0, 10)} • ${s['payment_method']}'), trailing: Text('${(s['total'] as num).toStringAsFixed(2)} د.أ'))),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الدفعات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), Text('${payments.length} دفعة')]),
        ...payments.map((p) => ListTile(leading: const Icon(Icons.check_circle_outline), title: Text('${(p['amount'] as num).toStringAsFixed(2)} د.أ'), subtitle: Text('${p['created_at'].toString().substring(0, 10)}${(p['note'] ?? '').toString().isEmpty ? '' : ' • ${p['note']}'}'))),
        if (sales.isEmpty && payments.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد حركة على الحساب'))),
      ]),
    )),
  );
}
