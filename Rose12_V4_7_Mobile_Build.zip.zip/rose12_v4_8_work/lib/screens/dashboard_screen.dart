import 'package:flutter/material.dart';
import '../database/app_database.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int products = 0;
  int pending = 0;
  int lowStock = 0;
  int salesCount = 0;
  double salesToday = 0;
  double expensesToday = 0;
  double netProfitToday = 0;
  double customerDebt = 0;
  double supplierDebt = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance.database;
    final p = await AppDatabase.instance.productCount();
    final s = await AppDatabase.instance.pendingSyncCount();
    final summary = await AppDatabase.instance.localSummary();
    final profit = await AppDatabase.instance.profitSummary();
    final low = await AppDatabase.instance.lowStockProducts();
    final customer = await db.rawQuery('SELECT COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END),0) total FROM customers');
    final supplier = await db.rawQuery('SELECT COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END),0) total FROM suppliers');
    if (!mounted) return;
    setState(() {
      products = p;
      pending = s;
      lowStock = low.length;
      salesToday = summary['sales'] ?? 0;
      expensesToday = summary['expenses'] ?? 0;
      salesCount = (summary['count'] ?? 0).round();
      netProfitToday = profit['net_profit'] ?? 0;
      customerDebt = (customer.first['total'] as num?)?.toDouble() ?? 0;
      supplierDebt = (supplier.first['total'] as num?)?.toDouble() ?? 0;
    });
  }

  String money(double v) => '${v.toStringAsFixed(2)} د.أ';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rose12')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('لوحة التحكم', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('ملخص سريع لحالة المبيعات والمخزون والحسابات', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 18),
              _heroCard(),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: _stat('المنتجات', '$products', Icons.inventory_2_outlined)),
                const SizedBox(width: 10),
                Expanded(child: _stat('مخزون منخفض', '$lowStock', Icons.warning_amber_outlined)),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _stat('ديون العملاء', money(customerDebt), Icons.people_alt_outlined)),
                const SizedBox(width: 10),
                Expanded(child: _stat('مستحق للموردين', money(supplierDebt), Icons.local_shipping_outlined)),
              ]),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('اختصارات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Wrap(spacing: 10, runSpacing: 10, children: [
                      _quick(context, 'بيع جديد', Icons.point_of_sale, '/pos'),
                      _quick(context, 'المنتجات', Icons.inventory_2_outlined, '/products'),
                      _quick(context, 'إدارة المخزون', Icons.warehouse_outlined, '/inventory'),
                      _quick(context, 'إضافة منتج', Icons.add_box_outlined, '/add-product'),
                      _quick(context, 'المبيعات', Icons.receipt_long, '/sales'),
                      _quick(context, 'المشتريات', Icons.shopping_cart_outlined, '/advanced-management'),
                      _quick(context, 'المزامنة', Icons.sync, '/sync'),
                      _quick(context, 'العملاء', Icons.people_alt_outlined, '/customers'),
                      _quick(context, 'الحسابات المالية', Icons.account_balance_wallet_outlined, '/financial-accounts'),
                      _quick(context, 'المصروفات', Icons.money_off, '/expenses'),
                      _quick(context, 'التقارير', Icons.assessment_outlined, '/reports'),
                      _quick(context, 'صحة النظام والسجل', Icons.health_and_safety_outlined, '/system-health'),
                      _quick(context, 'التنبيهات والمهام', Icons.notifications_active_outlined, '/alerts'),
                      _quick(context, 'لوحة المشرف', Icons.admin_panel_settings, '/supervisor-login'),
                      _quick(context, 'الإدارة المتقدمة', Icons.settings_suggest_outlined, '/advanced-management'),
                    ]),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _heroCard() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF9BCBEA), Color(0xFF5E9FCC)]),
      borderRadius: BorderRadius.circular(22),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('مبيعات اليوم', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 6),
      Text(money(salesToday), style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Text('$salesCount فاتورة  •  مصروفات ${money(expensesToday)}', style: const TextStyle(color: Colors.white70)),
      const SizedBox(height: 6),
      Text('صافي الربح اليوم: ${money(netProfitToday)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text('بانتظار المزامنة: $pending', style: const TextStyle(color: Colors.white70)),
    ]),
  );

  Widget _stat(String title, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
      Icon(icon, color: const Color(0xFF2C668F)), const SizedBox(height: 7),
      Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 3), Text(title, style: const TextStyle(color: Colors.grey), textAlign: TextAlign.center),
    ])),
  );

  Widget _quick(BuildContext context, String title, IconData icon, String route) => SizedBox(
    width: 145,
    child: OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, route), icon: Icon(icon), label: Text(title)),
  );
}
