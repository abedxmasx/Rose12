import 'package:flutter/material.dart';
import 'database/app_database.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/products_screen.dart';
import 'screens/add_product_screen.dart';
import 'screens/pos_screen.dart';
import 'screens/sync_screen.dart';
import 'screens/sales_history_screen.dart';
import 'services/sync_service.dart';
import 'screens/supervisor_login_screen.dart';
import 'screens/supervisor_dashboard_screen.dart';
import 'screens/customers_screen.dart';
import 'screens/customer_account_screen.dart';
import 'screens/expenses_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/advanced_management_screen.dart';
import 'screens/device_management_screen.dart';
import 'screens/inventory_screen.dart';
import 'screens/financial_accounts_screen.dart';
import 'screens/system_health_screen.dart';
import 'screens/product_price_history_screen.dart';
import 'screens/backup_restore_screen.dart';
import 'screens/alerts_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  SyncService.instance.startAutoSync();
  runApp(const Rose12App());
}

class Rose12App extends StatelessWidget {
  const Rose12App({super.key});

  static const pearl = Color(0xFFF7F8F7);
  static const sky = Color(0xFF78B4DD);
  static const deepBlue = Color(0xFF2C668F);
  static const gold = Color(0xFFC79A55);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rose12',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pearl,
        colorScheme: ColorScheme.fromSeed(seedColor: sky),
        appBarTheme: const AppBarTheme(
          backgroundColor: pearl,
          foregroundColor: deepBlue,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        if (settings.name == '/product-price-history') {
          final product = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(builder: (_) => ProductPriceHistoryScreen(product: product));
        }
        return null;
      },
      routes: {
        '/': (_) => const SplashScreen(),
        '/login': (_) => const LoginScreen(),
        '/dashboard': (_) => const DashboardScreen(),
        '/products': (_) => const ProductsScreen(),
        '/add-product': (_) => const AddProductScreen(),
        '/pos': (_) => const PosScreen(),
        '/sync': (_) => const SyncScreen(),
        '/sales': (_) => const SalesHistoryScreen(),
        '/supervisor-login': (_) => const SupervisorLoginScreen(),
        '/supervisor': (_) => const SupervisorDashboardScreen(),
        '/customers': (_) => const CustomersScreen(),
        '/expenses': (_) => const ExpensesScreen(),
        '/reports': (_) => const ReportsScreen(),
        '/advanced-management': (_) => const AdvancedManagementScreen(),
        '/devices': (_) => const DeviceManagementScreen(),
        '/inventory': (_) => const InventoryScreen(),
        '/financial-accounts': (_) => const FinancialAccountsScreen(),
        '/system-health': (_) => const SystemHealthScreen(),
        '/backup-restore': (_) => const BackupRestoreScreen(),
        '/alerts': (_) => const AlertsScreen(),
      },
    );
  }
}
