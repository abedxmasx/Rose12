import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class ReportExportService {
  static String _money(num v) => '${v.toDouble().toStringAsFixed(2)} د.أ';

  static Future<Uint8List> buildPdf({
    required String from,
    required String to,
    required Map<String, double> totals,
    required List<Map<String, dynamic>> products,
    required List<Map<String, dynamic>> expenseCategories,
    required List<Map<String, dynamic>> lowStock,
  }) async {
    final pdf = pw.Document();
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/Amiri-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/Amiri-Bold.ttf'));
    pw.MemoryImage? logo;
    try {
      logo = pw.MemoryImage((await rootBundle.load('assets/rose12_logo.png')).buffer.asUint8List());
    } catch (_) {}

    pw.Widget metric(String label, double value) => pw.Container(
      padding: const pw.EdgeInsets.all(7),
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400)),
      child: pw.Row(children: [pw.Expanded(child: pw.Text(label, style: pw.TextStyle(font: regular, fontSize: 9))), pw.Text(_money(value), style: pw.TextStyle(font: bold, fontSize: 9))]),
    );

    pdf.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(24),
      theme: pw.ThemeData.withFont(base: regular, bold: bold),
      build: (_) => [
        pw.Directionality(textDirection: pw.TextDirection.rtl, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          if (logo != null) pw.Center(child: pw.Image(logo!, width: 75, height: 48)),
          pw.Center(child: pw.Text('Rose12', style: pw.TextStyle(font: bold, fontSize: 20))),
          pw.Center(child: pw.Text('تقرير مالي وإحصائي', style: pw.TextStyle(font: bold, fontSize: 14))),
          pw.SizedBox(height: 6),
          pw.Center(child: pw.Text('الفترة: $from إلى $to', style: pw.TextStyle(font: regular, fontSize: 10))),
          pw.SizedBox(height: 12),
          pw.Wrap(spacing: 7, runSpacing: 7, children: [
            metric('المبيعات', totals['sales'] ?? 0), metric('المرتجعات', totals['returns'] ?? 0),
            metric('صافي المبيعات', totals['revenue'] ?? 0), metric('التكلفة', totals['cost'] ?? 0),
            metric('الربح الإجمالي', totals['gross'] ?? 0), metric('المصروفات', totals['expenses'] ?? 0),
            metric('صافي الربح', totals['net'] ?? 0), metric('المشتريات', totals['purchases'] ?? 0),
            metric('نقدي', totals['cash'] ?? 0), metric('آجل', totals['credit'] ?? 0),
          ]),
          pw.SizedBox(height: 16),
          pw.Text('أكثر المنتجات مبيعًا', style: pw.TextStyle(font: bold, fontSize: 13)),
          pw.SizedBox(height: 5),
          pw.Table(border: pw.TableBorder.all(color: PdfColors.grey400), children: [
            _row(['المنتج', 'الكمية', 'المبيعات', 'الربح التقريبي'], bold, true),
            ...products.take(20).map((x) {
              final gross = (x['gross'] as num?)?.toDouble() ?? 0;
              final cost = (x['cost'] as num?)?.toDouble() ?? 0;
              return _row(['${x['name']}', '${x['qty']}', _money(gross), _money(gross-cost)], regular, false);
            }),
          ]),
          pw.SizedBox(height: 14),
          pw.Text('المصروفات حسب التصنيف', style: pw.TextStyle(font: bold, fontSize: 13)),
          pw.SizedBox(height: 5),
          pw.Table(border: pw.TableBorder.all(color: PdfColors.grey400), children: [
            _row(['التصنيف', 'الإجمالي'], bold, true),
            ...expenseCategories.map((x) => _row(['${x['category']}', _money((x['total'] as num?) ?? 0)], regular, false)),
          ]),
          pw.SizedBox(height: 14),
          pw.Text('المخزون المنخفض', style: pw.TextStyle(font: bold, fontSize: 13)),
          pw.SizedBox(height: 5),
          pw.Table(border: pw.TableBorder.all(color: PdfColors.grey400), children: [
            _row(['المنتج', 'المتوفر', 'الحد الأدنى'], bold, true),
            ...lowStock.map((x) => _row(['${x['name']}', '${x['quantity']} ${x['unit']}', '${x['min_stock']} ${x['unit']}'], regular, false)),
          ]),
        ])),
      ],
    ));
    return pdf.save();
  }

  static pw.TableRow _row(List<String> values, pw.Font font, bool header) => pw.TableRow(
    decoration: header ? const pw.BoxDecoration(color: PdfColors.grey200) : null,
    children: values.map((v) => pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text(v, textAlign: pw.TextAlign.center, style: pw.TextStyle(font: font, fontSize: 8)))).toList(),
  );

  static Uint8List buildExcel({
    required String from,
    required String to,
    required Map<String, double> totals,
    required List<Map<String, dynamic>> products,
    required List<Map<String, dynamic>> expenseCategories,
    required List<Map<String, dynamic>> lowStock,
  }) {
    final excel = Excel.createExcel();
    final summary = excel['الملخص'];
    summary.appendRow([TextCellValue('Rose12 - التقرير المالي'), TextCellValue('$from إلى $to')]);
    final labels = <String, double>{
      'المبيعات': totals['sales'] ?? 0, 'المرتجعات': totals['returns'] ?? 0,
      'صافي المبيعات': totals['revenue'] ?? 0, 'التكلفة': totals['cost'] ?? 0,
      'الربح الإجمالي': totals['gross'] ?? 0, 'المصروفات': totals['expenses'] ?? 0,
      'صافي الربح': totals['net'] ?? 0, 'المشتريات': totals['purchases'] ?? 0,
      'نقدي': totals['cash'] ?? 0, 'آجل': totals['credit'] ?? 0,
    };
    labels.forEach((k,v) => summary.appendRow([TextCellValue(k), DoubleCellValue(v)]));

    final prod = excel['المنتجات'];
    prod.appendRow([TextCellValue('المنتج'), TextCellValue('الكمية'), TextCellValue('المبيعات'), TextCellValue('الربح التقريبي')]);
    for (final x in products) {
      final gross=(x['gross'] as num?)?.toDouble() ?? 0; final cost=(x['cost'] as num?)?.toDouble() ?? 0;
      prod.appendRow([TextCellValue('${x['name']}'), DoubleCellValue((x['qty'] as num?)?.toDouble() ?? 0), DoubleCellValue(gross), DoubleCellValue(gross-cost)]);
    }

    final exp = excel['المصروفات'];
    exp.appendRow([TextCellValue('التصنيف'), TextCellValue('الإجمالي')]);
    for (final x in expenseCategories) exp.appendRow([TextCellValue('${x['category']}'), DoubleCellValue((x['total'] as num?)?.toDouble() ?? 0)]);

    final stock = excel['المخزون المنخفض'];
    stock.appendRow([TextCellValue('المنتج'), TextCellValue('المتوفر'), TextCellValue('الحد الأدنى'), TextCellValue('الوحدة')]);
    for (final x in lowStock) stock.appendRow([TextCellValue('${x['name']}'), DoubleCellValue((x['quantity'] as num?)?.toDouble() ?? 0), DoubleCellValue((x['min_stock'] as num?)?.toDouble() ?? 0), TextCellValue('${x['unit']}')]);

    excel.delete('Sheet1');
    return Uint8List.fromList(excel.save() ?? <int>[]);
  }
}
