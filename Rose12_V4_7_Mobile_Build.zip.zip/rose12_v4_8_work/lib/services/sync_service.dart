import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import 'app_config.dart';

class SyncService {
  SyncService._();
  static final instance = SyncService._();
  Timer? _timer;
  StreamSubscription<List<ConnectivityResult>>? _connectionSub;

  void startAutoSync() {
    _timer ??= Timer.periodic(const Duration(minutes: 2), (_) => syncNow());
    _connectionSub ??= Connectivity().onConnectivityChanged.listen((_) => syncNow());
  }

  Future<Map<String, dynamic>> status() async {
    final db = await AppDatabase.instance.database;
    final pending = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM sync_queue WHERE status = 'pending'")) ?? 0;
    final failed = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM sync_queue WHERE status = 'failed'")) ?? 0;
    return {'pending': pending, 'failed': failed, 'configured': AppConfig.apiBaseUrl.isNotEmpty};
  }

  Future<Map<String, List<Map<String, dynamic>>>> buildPendingPayload() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery("SELECT * FROM sync_queue WHERE status IN ('pending','failed') ORDER BY id ASC LIMIT 250");
    final out = <String, List<Map<String, dynamic>>>{};
    for (final q in rows) {
      final type = q['entity_type'] as String;
      final id = q['entity_id'];
      Map<String, dynamic>? entity;
      String? itemsTable;
      String? foreignKey;
      switch (type) {
        case 'sale': entity = (await db.query('sales', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; itemsTable='sale_items'; foreignKey='sale_id'; break;
        case 'purchase': entity = (await db.query('purchases', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; itemsTable='purchase_items'; foreignKey='purchase_id'; break;
        case 'return': entity = (await db.query('returns', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; itemsTable='return_items'; foreignKey='return_id'; break;
        case 'expense': entity = (await db.query('expenses', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'customer': entity = (await db.query('customers', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'customer_payment': entity = (await db.query('customer_payments', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'supplier': entity = (await db.query('suppliers', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'staff': entity = (await db.query('staff', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'stock_adjustment': entity = (await db.query('stock_adjustments', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
        case 'product': entity = (await db.query('products', where:'id=?', whereArgs:[id], limit:1)).firstOrNull; break;
      }
      if (entity == null) continue;
      final payload = <String,dynamic>{...entity, 'queue_id': q['id']};
      if (type == 'customer_payment') {
        final customerId = entity['customer_id'];
        if (customerId != null) {
          final customer = await db.query('customers', columns:['local_uuid'], where:'id=?', whereArgs:[customerId], limit:1);
          if (customer.isNotEmpty) payload['customer_local_uuid'] = customer.first['local_uuid'];
        }
      }
      if (itemsTable != null) {
        final rawItems = await db.query(itemsTable, where:'$foreignKey=?', whereArgs:[id]);
        final enriched = <Map<String, dynamic>>[];
        for (final item in rawItems) {
          final copy = <String, dynamic>{...item};
          final productId = item['product_id'];
          if (productId != null) {
            final product = await db.query('products', columns:['sync_uuid','server_id'], where:'id=?', whereArgs:[productId], limit:1);
            if (product.isNotEmpty) {
              copy['product_sync_uuid'] = product.first['sync_uuid'];
              copy['server_product_id'] = product.first['server_id'];
            }
          }
          enriched.add(copy);
        }
        payload['items'] = enriched;
      }
      (out[type] ??= []).add(payload);
    }
    return out;
  }

  Future<void> retryFailed() async {
    final db = await AppDatabase.instance.database;
    await db.update('sync_queue', {'status': 'pending', 'error_message': null}, where: "status='failed'");
  }

  Future<bool> pullProducts() async {
    if (AppConfig.apiBaseUrl.isEmpty || AppConfig.deviceKey.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    try {
      final r = await http.get(Uri.parse('${AppConfig.apiBaseUrl}/api/products/catalog'), headers:{'x-device-key':AppConfig.deviceKey}).timeout(const Duration(seconds:15));
      if (r.statusCode != 200) return false;
      final list = List<Map<String,dynamic>>.from(jsonDecode(r.body) as List);
      await db.transaction((txn) async {
        for (final p in list) {
          final existing = await txn.query('products', where:'sync_uuid=?', whereArgs:[p['sync_uuid']], limit:1);
          final data = <String,dynamic>{
            'name':p['name'],'sku':p['sku'],'barcode':p['barcode'],'category':p['category'],'unit':p['unit'],
            'cost_price':p['cost_price'],'sale_price':p['sale_price'],'wholesale_price':p['wholesale_price'],
            'quantity':p['quantity'],'min_stock':p['min_stock'],'sync_uuid':p['sync_uuid'],'server_id':p['id'],
            'updated_at':p['updated_at'],'created_at':p['created_at']
          };
          if (existing.isEmpty) { await txn.insert('products', data); }
          else { await txn.update('products', data, where:'id=?', whereArgs:[existing.first['id']]); }
        }
      });
      return true;
    } catch (_) { return false; }
  }

  Future<bool> syncNow() async {
    if (AppConfig.apiBaseUrl.isEmpty || AppConfig.deviceKey.isEmpty) return false;
    final entities = await buildPendingPayload();
    if (entities.isEmpty) return true;
    final db = await AppDatabase.instance.database;
    try {
      final r = await http.post(Uri.parse('${AppConfig.apiBaseUrl}/api/sync/batch'), headers:{'Content-Type':'application/json','x-device-key':AppConfig.deviceKey}, body:jsonEncode({'entities':entities})).timeout(const Duration(seconds:20));
      if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
      final data = jsonDecode(r.body) as Map<String,dynamic>;
      final accepted = (data['accepted'] as Map?)?.cast<String,dynamic>() ?? {};
      for (final entry in accepted.entries) {
        for (final qid in (entry.value as List? ?? const [])) {
          final q = await db.query('sync_queue', where:'id=?', whereArgs:[qid], limit:1);
          if (q.isEmpty) continue;
          await db.update('sync_queue', {'status':'sent','last_attempt_at':DateTime.now().toIso8601String(),'error_message':null}, where:'id=?', whereArgs:[qid]);
          await _markEntitySent(db, q.first['entity_type'] as String, q.first['entity_id'] as int);
        }
      }
      for (final rej in (data['rejected'] as List? ?? const [])) {
        final qid = rej['queue_id'];
        await db.rawUpdate(
          'UPDATE sync_queue SET status=?, attempts=attempts+1, last_attempt_at=?, error_message=? WHERE id=?',
          ['failed', DateTime.now().toIso8601String(), rej['error']?.toString(), qid],
        );
      }
      await pullProducts();
      return true;
    } catch (e) {
      await db.rawUpdate("UPDATE sync_queue SET status='failed', attempts=attempts+1, last_attempt_at=?, error_message=? WHERE status IN ('pending','failed')", [DateTime.now().toIso8601String(), e.toString()]);
      return false;
    }
  }

  Future<void> _markEntitySent(Database db, String type, int id) async {
    const map = {'sale':'sales','purchase':'purchases','return':'returns','expense':'expenses','customer':'customers','customer_payment':'customer_payments','supplier':'suppliers','staff':'staff','stock_adjustment':'stock_adjustments','product':'products'};
    final table = map[type];
    if (table != null) await db.update(table, {'sync_status':'sent'}, where:'id=?', whereArgs:[id]);
  }
}

extension _FirstOrNull<T> on List<T> { T? get firstOrNull => isEmpty ? null : first; }
