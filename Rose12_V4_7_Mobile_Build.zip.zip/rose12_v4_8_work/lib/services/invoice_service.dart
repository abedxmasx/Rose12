import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class InvoiceService {
  static Future<Uint8List> buildPdf({
    required Map<String, dynamic> sale,
    required List<Map<String, dynamic>> items,
    PdfPageFormat format = PdfPageFormat.a4,
  }) async {
    final pdf = pw.Document();
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/Amiri-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/Amiri-Bold.ttf'));
    pw.MemoryImage? logo;
    try {
      logo = pw.MemoryImage((await rootBundle.load('assets/rose12_logo.png')).buffer.asUint8List());
    } catch (_) {}

    final subtotal = ((sale['subtotal'] as num?)?.toDouble() ?? 0);
    final discount = ((sale['discount'] as num?)?.toDouble() ?? 0);
    final total = ((sale['total'] as num?)?.toDouble() ?? 0);
    final customer = '${sale['customer_name'] ?? ''}'.trim();
    final invoice = '${sale['invoice_number'] ?? ''}';
    final date = '${sale['created_at'] ?? ''}';

    pdf.addPage(
      pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(28),
        theme: pw.ThemeData.withFont(base: regular, bold: bold),
        build: (context) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                if (logo != null)
                  pw.Center(child: pw.Image(logo!, width: 90, height: 55, fit: pw.BoxFit.contain)),
                pw.SizedBox(height: 4),
                pw.Center(child: pw.Text('Rose12', style: pw.TextStyle(font: bold, fontSize: 22))),
                pw.Center(child: pw.Text('فاتورة مبيعات', style: pw.TextStyle(font: bold, fontSize: 15))),
                pw.SizedBox(height: 14),
                pw.Container(
                  padding: const pw.EdgeInsets.all(10),
                  decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400), borderRadius: pw.BorderRadius.circular(6)),
                  child: pw.Column(children: [
                    _infoRow('رقم الفاتورة', invoice, regular, bold),
                    _infoRow('التاريخ', date, regular, bold),
                    if (customer.isNotEmpty) _infoRow('العميل', customer, regular, bold),
                    _infoRow('طريقة الدفع', '${sale['payment_method'] ?? ''}', regular, bold),
                  ]),
                ),
                pw.SizedBox(height: 14),
                pw.Table(
                  border: pw.TableBorder.all(color: PdfColors.grey400),
                  columnWidths: const {0: pw.FlexColumnWidth(3.5), 1: pw.FlexColumnWidth(1), 2: pw.FlexColumnWidth(1.5), 3: pw.FlexColumnWidth(1.7)},
                  children: [
                    _row(['المنتج', 'الكمية', 'سعر الوحدة', 'الإجمالي'], bold, true),
                    ...items.map((x) => _row([
                      '${x['product_name'] ?? ''}',
                      '${x['quantity'] ?? 0}',
                      '${((x['unit_price'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ',
                      '${((x['total'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ',
                    ], regular, false)),
                  ],
                ),
                pw.SizedBox(height: 12),
                pw.Align(
                  alignment: pw.Alignment.centerLeft,
                  child: pw.Container(
                    width: 250,
                    padding: const pw.EdgeInsets.all(10),
                    child: pw.Column(children: [
                      _totalRow('المجموع الفرعي', subtotal, regular),
                      _totalRow('الخصم', -discount, regular),
                      pw.Divider(),
                      _totalRow('الإجمالي', total, bold),
                    ]),
                  ),
                ),
                pw.SizedBox(height: 25),
                pw.Center(child: pw.Text('شكراً لتعاملكم مع Rose12', style: pw.TextStyle(font: bold, fontSize: 13))),
              ],
            ),
          ),
        ],
      ),
    );
    return pdf.save();
  }

  static pw.TableRow _row(List<String> values, pw.Font font, bool header) {
    return pw.TableRow(
      decoration: header ? const pw.BoxDecoration(color: PdfColors.grey200) : null,
      children: values.map((v) => pw.Padding(
        padding: const pw.EdgeInsets.all(6),
        child: pw.Text(v, textAlign: pw.TextAlign.center, style: pw.TextStyle(font: font, fontSize: header ? 10 : 9)),
      )).toList(),
    );
  }

  static pw.Widget _infoRow(String label, String value, pw.Font regular, pw.Font bold) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(children: [
        pw.Expanded(child: pw.Text(value, style: pw.TextStyle(font: regular, fontSize: 10))),
        pw.SizedBox(width: 8),
        pw.Text('$label:', style: pw.TextStyle(font: bold, fontSize: 10)),
      ]),
    );
  }

  static pw.Widget _totalRow(String label, double value, pw.Font font) {
    final text = '${value < 0 ? '- ' : ''}${value.abs().toStringAsFixed(2)} د.أ';
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3),
      child: pw.Row(children: [
        pw.Expanded(child: pw.Text(text, style: pw.TextStyle(font: font, fontSize: label == 'الإجمالي' ? 13 : 10))),
        pw.Text(label, style: pw.TextStyle(font: font, fontSize: label == 'الإجمالي' ? 13 : 10)),
      ]),
    );
  }
}
