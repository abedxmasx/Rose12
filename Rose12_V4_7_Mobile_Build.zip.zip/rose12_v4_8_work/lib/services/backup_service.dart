import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../database/app_database.dart';

class BackupService {
  BackupService._();
  static final instance = BackupService._();

  Future<Directory> _backupDir() async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(root.path, 'Rose12_Backups'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<List<File>> listBackups() async {
    final dir = await _backupDir();
    final files = <File>[];
    await for (final entity in dir.list()) {
      if (entity is File && p.extension(entity.path).toLowerCase() == '.db') files.add(entity);
    }
    files.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    return files;
  }

  Future<bool> isValidDatabase(File file) async {
    if (!await file.exists()) return false;
    if (await file.length() < 100) return false;
    final raf = await file.open();
    try {
      final bytes = await raf.read(16);
      const magic = 'SQLite format 3\u0000';
      return bytes.length == 16 && String.fromCharCodes(bytes) == magic;
    } finally { await raf.close(); }
  }

  Future<File> createBackup({String reason = 'manual'}) async {
    final dbPath = await AppDatabase.instance.databasePath();
    final source = File(dbPath);
    if (!await source.exists()) throw Exception('قاعدة البيانات غير موجودة');
    final dir = await _backupDir();
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
    final target = File(p.join(dir.path, 'rose12_${reason}_$stamp.db'));
    await source.copy(target.path);
    if (!await isValidDatabase(target)) {
      await target.delete().catchError((_) => target);
      throw Exception('تعذر التحقق من سلامة النسخة الاحتياطية');
    }
    return target;
  }

  Future<void> shareBackup(File file) async {
    if (!await isValidDatabase(file)) throw Exception('النسخة غير صالحة للمشاركة');
    await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية من قاعدة بيانات Rose12');
  }

  Future<File?> pickBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['db']);
    if (result == null || result.files.single.path == null) return null;
    final file = File(result.files.single.path!);
    if (!await isValidDatabase(file)) throw Exception('الملف المختار ليس نسخة SQLite صالحة لـ Rose12');
    return file;
  }

  Future<void> deleteBackup(File file) async {
    if (await file.exists()) await file.delete();
  }

  Future<void> restoreBackup(File backup) async {
    if (!await isValidDatabase(backup)) throw Exception('ملف النسخة الاحتياطية غير صالح');
    // Safety copy of the current database before replacing it.
    await createBackup(reason: 'before_restore');
    final dbPath = await AppDatabase.instance.databasePath();
    await AppDatabase.instance.close();
    try {
      await backup.copy(dbPath);
    } finally {
      await AppDatabase.instance.reopen();
    }
  }
}
