import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';

class SupervisorService {
  SupervisorService._();
  static final instance = SupervisorService._();
  String? token;
  String? name;

  Future<bool> login(String username, String password) async {
    if (AppConfig.apiBaseUrl.isEmpty) return false;
    final r = await http.post(
      Uri.parse('${AppConfig.apiBaseUrl}/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    ).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) return false;
    final data = jsonDecode(r.body) as Map<String, dynamic>;
    token = data['token'] as String?;
    name = data['name'] as String?;
    return token != null;
  }

  Future<Map<String, dynamic>> summary() async {
    final r = await _get('/api/dashboard/summary');
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<List<Map<String, dynamic>>> sales() async {
    final r = await _get('/api/sales');
    return List<Map<String, dynamic>>.from(jsonDecode(r.body) as List);
  }

  Future<List<Map<String, dynamic>>> devices() async {
    final r = await _get('/api/admin/devices');
    return List<Map<String, dynamic>>.from(jsonDecode(r.body) as List);
  }

  Future<bool> setDeviceActive(int id, bool active) async {
    final r = await http.patch(
      Uri.parse('${AppConfig.apiBaseUrl}/api/admin/devices/$id'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'active': active}),
    ).timeout(const Duration(seconds: 15));
    return r.statusCode == 200;
  }

  Future<bool> registerDevice(String deviceKey, String name) async {
    final r = await http.post(
      Uri.parse('${AppConfig.apiBaseUrl}/api/admin/devices'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'device_key': deviceKey, 'name': name}),
    ).timeout(const Duration(seconds: 15));
    return r.statusCode == 201;
  }

  Future<List<Map<String, dynamic>>> auditLogs() async {
    final r = await _get('/api/audit');
    return List<Map<String, dynamic>>.from(jsonDecode(r.body) as List);
  }

  Future<http.Response> _get(String path) => http.get(
    Uri.parse('${AppConfig.apiBaseUrl}$path'),
    headers: {'Authorization': 'Bearer $token'},
  ).timeout(const Duration(seconds: 15));
}
