class AppConfig {
  static const String apiBaseUrl = String.fromEnvironment('ROSE12_API_URL', defaultValue: '');
  static const String deviceKey = String.fromEnvironment('ROSE12_DEVICE_KEY', defaultValue: '');
}
