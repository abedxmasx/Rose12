# Rose12 V2.5 — Sales Reports

- Payment-method filter remains available in sales history.
- Reports show cash and credit totals only; no card total is displayed.
- Preserves name-only product search.
- No barcode UI.
- No shifts.
- No cashier management.
- No database migration required for V2.5.
