# Rose12 V4.3 — Price History & Product Audit

- Added product price history for cost, sale, and wholesale prices.
- Database upgraded to version 11.
- Price changes are recorded automatically when editing a product.
- Added a product price-history screen accessible from Edit Product.
- Product updates continue to enter the sync queue and audit log.
- Sales remain name-search only; no barcode UI.
- No shifts or cashier management.
- Sales payment methods remain cash and credit only; no card.

Flutter/Dart build was not run in this environment because Flutter SDK is unavailable.
