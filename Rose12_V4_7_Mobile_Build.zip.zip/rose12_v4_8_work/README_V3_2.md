# Rose12 V3.2 — Customer Accounts UX

- Customer list now supports search by name or phone.
- Tapping a customer opens the full account page.
- Customer account shows current outstanding balance, deferred invoices, and payments.
- Customer payment remains offline-first and is queued for synchronization.
- Payment cannot exceed the current outstanding balance.
- Refresh is available on customer list and account pages.
- Sales remain name-based only: no barcode workflow.
- Payment methods remain cash and credit only.
- No shifts and no cashier management.
