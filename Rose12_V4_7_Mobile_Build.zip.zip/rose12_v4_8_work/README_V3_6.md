# Rose12 V3.6 — Purchases & Suppliers

- Professional purchase invoice flow.
- Supplier account details and payments.
- Supplier payment validation against outstanding balance.
- Purchase invoice detail view with items, totals, paid and remaining.
- Purchase updates stock and supplier balance.
- Supplier payments are queued for sync and audited.
- Offline-first remains enabled.
- Sales remain name-only: no barcode.
- No shifts, no cashier management.
- Sales payment methods remain cash or credit only.
