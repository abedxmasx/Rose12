# Rose12 V3.3 — Sync & Customer Payments

- Offline-first synchronization improvements.
- Customer records have a stable local UUID for server upsert/update.
- Customer payments are included in the sync queue and backend API.
- Customer payment sync is idempotent using local_uuid.
- Failed sync items can be retried from the Sync screen.
- Sync screen now has a real “Sync now” action and retry-failed action.
- Backend API version 2.0.
- Existing Rose12 rules remain unchanged:
  - POS searches by product name only.
  - No barcode in sales UI.
  - No shifts.
  - No cashier management.
  - Payment methods are cash and credit only; no card.

Flutter SDK was not available in the build environment, so flutter analyze/run/build were not executed.
The backend JavaScript file was checked with `node --check`.
