# Rose12 Supervisor API

1. Node.js 20+.
2. `npm install`
3. `npm start`

Environment: `PORT`, `JWT_SECRET`, `SUPERVISOR_PASSWORD`, `DEVICE_KEY`.

Initial accounts: `supervisor1` and `supervisor2`. Default password is `Rose12@123` only when `SUPERVISOR_PASSWORD` is not supplied. Change it before production.

API: `GET /api/health`, `POST /api/auth/login`, `POST /api/sync/sales` with `x-device-key`, `GET /api/dashboard/summary`, `GET /api/sales` with Bearer token.

Use HTTPS and strong secrets in production.
