# Rose12 V3.9 — Financial Accounts

- Added a dedicated financial accounts center for customers and suppliers.
- Customer account ledger: credit invoices and customer payments.
- Supplier account ledger: outstanding purchase invoices and supplier payments.
- Current customer debt and supplier payable totals.
- Pull-to-refresh and direct account details.
- Added dashboard shortcut and route.
- Sales remains name-search only; no barcode workflow, shifts, or cashier management.
- Sales payment methods remain cash and credit only.

Flutter/Dart build was not run in this environment because the Flutter SDK is unavailable.
