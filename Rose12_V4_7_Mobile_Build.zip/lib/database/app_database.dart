import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<String> databasePath() async => join(await getDatabasesPath(), 'rose12.db');

  Future<void> close() async {
    if (_db != null) {
      await _db!.close();
      _db = null;
    }
  }

  Future<void> reopen() async {
    await close();
    await database;
  }

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await databasePath();
    _db = await openDatabase(
      dbPath,
      version: 11,
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, balance REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT, amount REAL NOT NULL, note TEXT, created_at TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'pending')");
        }
        if (oldVersion < 3) {
          await db.execute("CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, balance REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, local_uuid TEXT NOT NULL UNIQUE, supplier_id INTEGER, invoice_number TEXT NOT NULL UNIQUE, subtotal REAL NOT NULL, paid_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL, payment_method TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity REAL NOT NULL, unit_cost REAL NOT NULL, total REAL NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY AUTOINCREMENT, local_uuid TEXT NOT NULL UNIQUE, sale_id INTEGER, invoice_number TEXT, total REAL NOT NULL, reason TEXT, sync_status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS return_items(id INTEGER PRIMARY KEY AUTOINCREMENT, return_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity REAL NOT NULL, unit_price REAL NOT NULL, total REAL NOT NULL)");
          await db.execute("CREATE TABLE IF NOT EXISTS stock_adjustments(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, quantity_change REAL NOT NULL, reason TEXT, created_at TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'pending')");
        }
        if (oldVersion < 4) {
          await db.execute("CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity_type TEXT, entity_id INTEGER, details TEXT, created_at TEXT NOT NULL)");
        }
        if (oldVersion < 5) {
          await db.execute("ALTER TABLE products ADD COLUMN sync_uuid TEXT");
          await db.execute("ALTER TABLE products ADD COLUMN server_id INTEGER");
          await db.execute("ALTER TABLE products ADD COLUMN updated_at TEXT");
          await db.execute("UPDATE products SET sync_uuid=lower(hex(randomblob(16))) WHERE sync_uuid IS NULL");
          await db.execute("UPDATE products SET updated_at=created_at WHERE updated_at IS NULL");
        }
        if (oldVersion < 6) {
          await db.execute('ALTER TABLE sales ADD COLUMN customer_id INTEGER');
        }
        if (oldVersion < 7) {
          await db.execute('''CREATE TABLE IF NOT EXISTS customer_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            local_uuid TEXT UNIQUE
          )''');
        }
        if (oldVersion < 9) {
          await db.execute('ALTER TABLE customers ADD COLUMN local_uuid TEXT');
          await db.execute('UPDATE customers SET local_uuid = lower(hex(randomblob(16))) WHERE local_uuid IS NULL');
          await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_local_uuid ON customers(local_uuid)');
          await db.execute('ALTER TABLE customer_payments ADD COLUMN local_uuid TEXT');
          await db.execute('UPDATE customer_payments SET local_uuid = lower(hex(randomblob(16))) WHERE local_uuid IS NULL');
          await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_customer_payments_local_uuid ON customer_payments(local_uuid)');
        }
        if (oldVersion < 11) {
          await db.execute('''CREATE TABLE IF NOT EXISTS product_price_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            old_cost_price REAL NOT NULL,
            new_cost_price REAL NOT NULL,
            old_sale_price REAL NOT NULL,
            new_sale_price REAL NOT NULL,
            old_wholesale_price REAL NOT NULL,
            new_wholesale_price REAL NOT NULL,
            changed_at TEXT NOT NULL
          )''');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_product_price_history_product ON product_price_history(product_id)');
        }
        if (oldVersion < 10) {
          await db.execute('''CREATE TABLE IF NOT EXISTS supplier_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            supplier_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            local_uuid TEXT UNIQUE
          )''');
          await db.execute('UPDATE suppliers SET balance = balance WHERE id = id');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments(supplier_id)');
        }
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            sku TEXT,
            barcode TEXT,
            category TEXT,
            unit TEXT NOT NULL DEFAULT 'قطعة',
            cost_price REAL NOT NULL DEFAULT 0,
            sale_price REAL NOT NULL DEFAULT 0,
            wholesale_price REAL NOT NULL DEFAULT 0,
            quantity REAL NOT NULL DEFAULT 0,
            min_stock REAL NOT NULL DEFAULT 0,
            sync_uuid TEXT,
            server_id INTEGER,
            updated_at TEXT,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE product_price_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            old_cost_price REAL NOT NULL,
            new_cost_price REAL NOT NULL,
            old_sale_price REAL NOT NULL,
            new_sale_price REAL NOT NULL,
            old_wholesale_price REAL NOT NULL,
            new_wholesale_price REAL NOT NULL,
            changed_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_uuid TEXT NOT NULL UNIQUE,
            invoice_number TEXT NOT NULL UNIQUE,
            customer_name TEXT,
            customer_id INTEGER,
            subtotal REAL NOT NULL,
            discount REAL NOT NULL DEFAULT 0,
            tax REAL NOT NULL DEFAULT 0,
            total REAL NOT NULL,
            paid_amount REAL NOT NULL DEFAULT 0,
            payment_method TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            quantity REAL NOT NULL,
            unit_price REAL NOT NULL,
            total REAL NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE inventory_movements(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            quantity REAL NOT NULL,
            reference_id INTEGER,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, balance REAL NOT NULL DEFAULT 0, local_uuid TEXT UNIQUE, created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE customer_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            local_uuid TEXT UNIQUE
          )
        ''');
        await db.execute('''
          CREATE TABLE expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT, amount REAL NOT NULL, note TEXT, created_at TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'pending'
          )
        ''');
        await db.execute('''
          CREATE TABLE staff(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE,
            role TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE suppliers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            balance REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE supplier_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            supplier_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            note TEXT,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            local_uuid TEXT UNIQUE
          )
        ''');
        await db.execute('''
          CREATE TABLE purchases(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_uuid TEXT NOT NULL UNIQUE,
            supplier_id INTEGER,
            invoice_number TEXT NOT NULL UNIQUE,
            subtotal REAL NOT NULL,
            paid_amount REAL NOT NULL DEFAULT 0,
            total REAL NOT NULL,
            payment_method TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE purchase_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            purchase_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity REAL NOT NULL,
            unit_cost REAL NOT NULL,
            total REAL NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE returns(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_uuid TEXT NOT NULL UNIQUE,
            sale_id INTEGER,
            invoice_number TEXT,
            total REAL NOT NULL,
            reason TEXT,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE return_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            return_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity REAL NOT NULL,
            unit_price REAL NOT NULL,
            total REAL NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE stock_adjustments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            quantity_change REAL NOT NULL,
            reason TEXT,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending'
          )
        ''');
        await db.execute('''
          CREATE TABLE audit_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity_type TEXT, entity_id INTEGER, details TEXT, created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE sync_queue(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entity_type TEXT NOT NULL,
            entity_id INTEGER NOT NULL,
            operation_type TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0,
            last_attempt_at TEXT,
            error_message TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  Future<List<Map<String, dynamic>>> products() async {
    final db = await database;
    return db.query('products', orderBy: 'id DESC');
  }

  Future<int> addProduct(Map<String, dynamic> product) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    final data = <String,dynamic>{...product, 'sync_uuid': _localUuid(), 'updated_at': now};
    return db.transaction((txn) async {
      final id = await txn.insert('products', data);
      await txn.insert('sync_queue', {'entity_type':'product','entity_id':id,'operation_type':'create','status':'pending','attempts':0});
      return id;
    });
  }

  String _localUuid() => '${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}-${DateTime.now().millisecondsSinceEpoch.toRadixString(16)}';

  Future<void> updateProduct(int id, Map<String, dynamic> changes) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query('products', where: 'id=?', whereArgs: [id], limit: 1);
      if (rows.isEmpty) throw StateError('product not found');
      final old = rows.first;
      final oldCost = (old['cost_price'] as num?)?.toDouble() ?? 0;
      final oldSale = (old['sale_price'] as num?)?.toDouble() ?? 0;
      final oldWholesale = (old['wholesale_price'] as num?)?.toDouble() ?? 0;
      final newCost = (changes['cost_price'] as num?)?.toDouble() ?? oldCost;
      final newSale = (changes['sale_price'] as num?)?.toDouble() ?? oldSale;
      final newWholesale = (changes['wholesale_price'] as num?)?.toDouble() ?? oldWholesale;
      final now = DateTime.now().toIso8601String();
      final payload = Map<String, dynamic>.from(changes)..['updated_at'] = now;
      await txn.update('products', payload, where: 'id=?', whereArgs: [id]);
      if (oldCost != newCost || oldSale != newSale || oldWholesale != newWholesale) {
        await txn.insert('product_price_history', {
          'product_id': id,
          'old_cost_price': oldCost, 'new_cost_price': newCost,
          'old_sale_price': oldSale, 'new_sale_price': newSale,
          'old_wholesale_price': oldWholesale, 'new_wholesale_price': newWholesale,
          'changed_at': now,
        });
      }
      await txn.insert('sync_queue', {'entity_type':'product','entity_id':id,'operation_type':'update','status':'pending','attempts':0});
      await txn.insert('audit_logs', {'action':'update','entity_type':'product','entity_id':id,'details':'product updated','created_at':now});
    });
  }

  Future<List<Map<String, dynamic>>> productPriceHistory(int productId) async {
    final db = await database;
    return db.query('product_price_history', where: 'product_id=?', whereArgs: [productId], orderBy: 'id DESC');
  }

  Future<int> addCustomer({required String name, String? phone, String? address}) async {
    final db = await database;
    return db.transaction((txn) async { final now=DateTime.now().toIso8601String(); final localUuid = _localUuid(); final id=await txn.insert('customers', {'name': name, 'phone': phone, 'address': address, 'balance': 0, 'local_uuid': localUuid, 'created_at': now}); await txn.insert('sync_queue', {'entity_type':'customer','entity_id':id,'operation_type':'create','status':'pending','attempts':0}); return id; });
  }

  Future<List<Map<String, dynamic>>> customers() async {
    final db = await database;
    return db.query('customers', orderBy: 'id DESC');
  }

  Future<List<Map<String, dynamic>>> customerSales(int customerId) async {
    final db = await database;
    return db.query('sales', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'id DESC');
  }

  Future<List<Map<String, dynamic>>> customerPayments(int customerId) async {
    final db = await database;
    return db.query('customer_payments', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'id DESC');
  }

  Future<double> customerBalance(int customerId) async {
    final db = await database;
    final rows = await db.query('customers', columns: ['balance'], where: 'id=?', whereArgs: [customerId], limit: 1);
    if (rows.isEmpty) throw Exception('العميل غير موجود');
    return (rows.first['balance'] as num).toDouble();
  }

  Future<void> addCustomerPayment({required int customerId, required double amount, String? note}) async {
    if (amount <= 0) throw ArgumentError('amount must be positive');
    final db = await database;
    await db.transaction((txn) async {
      final customer = await txn.query('customers', columns: ['balance'], where: 'id=?', whereArgs: [customerId], limit: 1);
      if (customer.isEmpty) throw Exception('العميل غير موجود');
      final current = (customer.first['balance'] as num).toDouble();
      if (current <= 0) throw Exception('لا يوجد رصيد مستحق على هذا العميل');
      if (amount > current + 0.000001) {
        throw Exception('مبلغ الدفعة أكبر من الرصيد المستحق (${current.toStringAsFixed(2)} د.أ)');
      }
      final now = DateTime.now().toIso8601String();
      final paymentId = await txn.insert('customer_payments', {
        'customer_id': customerId,
        'amount': amount,
        'note': note,
        'created_at': now,
        'sync_status': 'pending',
        'local_uuid': _localUuid()
      });
      await txn.rawUpdate('UPDATE customers SET balance = balance - ? WHERE id = ?', [amount, customerId]);
      await txn.insert('sync_queue', {
        'entity_type': 'customer_payment',
        'entity_id': paymentId,
        'operation_type': 'create',
        'status': 'pending',
        'attempts': 0
      });
      await txn.insert('sync_queue', {
        'entity_type': 'customer',
        'entity_id': customerId,
        'operation_type': 'update',
        'status': 'pending',
        'attempts': 0
      });
      await txn.insert('audit_logs', {
        'action': 'customer_payment',
        'entity_type': 'customer_payment',
        'entity_id': paymentId,
        'details': 'customer=$customerId amount=$amount',
        'created_at': now
      });
    });
  }

  Future<int> addExpense({required String title, String? category, required double amount, String? note}) async {
    final db = await database;
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      final id = await txn.insert('expenses', {'title': title, 'category': category, 'amount': amount, 'note': note, 'created_at': now, 'sync_status': 'pending'});
      await txn.insert('sync_queue', {'entity_type':'expense','entity_id':id,'operation_type':'create','status':'pending','attempts':0});
      await txn.insert('audit_logs', {'action':'create','entity_type':'expense','entity_id':id,'details':title,'created_at':now});
      return id;
    });
  }

  Future<List<Map<String, dynamic>>> expenses() async {
    final db = await database;
    return db.query('expenses', orderBy: 'id DESC');
  }

  Future<int> createSale({
    required String localUuid,
    required String invoiceNumber,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    double discount = 0,
    double tax = 0,
    required double total,
    required double paidAmount,
    required String paymentMethod,
    int? customerId,
    String? customerName,
  }) async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final now = DateTime.now().toIso8601String();
      final saleId = await txn.insert('sales', {
        'local_uuid': localUuid,
        'invoice_number': invoiceNumber,
        'customer_name': customerName,
        'customer_id': customerId,
        'subtotal': subtotal,
        'discount': discount,
        'tax': tax,
        'total': total,
        'paid_amount': paidAmount,
        'payment_method': paymentMethod,
        'sync_status': 'pending',
        'created_at': now,
      });

      for (final item in items) {
        final productId = item['product_id'] as int;
        final qty = item['qty'] as int;
        await txn.insert('sale_items', {
          'sale_id': saleId,
          'product_id': productId,
          'product_name': item['name'],
          'quantity': qty,
          'unit_price': item['price'],
          'total': item['price'] * qty,
        });
        await txn.rawUpdate(
          'UPDATE products SET quantity = quantity - ? WHERE id = ?',
          [qty, productId],
        );
        await txn.insert('inventory_movements', {
          'product_id': productId,
          'type': 'sale',
          'quantity': -qty,
          'reference_id': saleId,
          'created_at': now,
        });
      }

      if (customerId != null && paymentMethod == 'آجل') {
        final balanceDue = total - paidAmount;
        if (balanceDue > 0) {
          await txn.rawUpdate('UPDATE customers SET balance = balance + ? WHERE id = ?', [balanceDue, customerId]);
          await txn.insert('sync_queue', {
            'entity_type': 'customer',
            'entity_id': customerId,
            'operation_type': 'update',
            'status': 'pending',
            'attempts': 0,
          });
        }
      }

      await txn.insert('sync_queue', {
        'entity_type': 'sale',
        'entity_id': saleId,
        'operation_type': 'create',
        'status': 'pending',
        'attempts': 0,
      });
      return saleId;
    });
  }
  Future<List<Map<String, dynamic>>> suppliers() async {
    final db = await database;
    return db.query('suppliers', orderBy: 'id DESC');
  }

  Future<int> addSupplier({required String name, String? phone, String? address}) async {
    final db = await database;
    return db.transaction((txn) async { final now=DateTime.now().toIso8601String(); final id=await txn.insert('suppliers', {'name': name, 'phone': phone, 'address': address, 'balance': 0, 'created_at': now}); await txn.insert('sync_queue', {'entity_type':'supplier','entity_id':id,'operation_type':'create','status':'pending','attempts':0}); return id; });
  }

  Future<List<Map<String, dynamic>>> staff() async {
    final db = await database;
    return db.query('staff', where: 'active = 1', orderBy: 'id DESC');
  }

  Future<int> addStaff({required String name, required String username, required String role}) async {
    final db = await database;
    return db.transaction((txn) async { final now=DateTime.now().toIso8601String(); final id=await txn.insert('staff', {'name': name, 'username': username, 'role': role, 'active': 1, 'created_at': now}); await txn.insert('sync_queue', {'entity_type':'staff','entity_id':id,'operation_type':'create','status':'pending','attempts':0}); return id; });
  }

  Future<int> addStockAdjustment({required int productId, required double quantityChange, String? reason}) async {
    final db = await database;
    return db.transaction((txn) async {
      await txn.rawUpdate('UPDATE products SET quantity = quantity + ? WHERE id = ?', [quantityChange, productId]);
      final id = await txn.insert('stock_adjustments', {'product_id': productId, 'quantity_change': quantityChange, 'reason': reason, 'created_at': DateTime.now().toIso8601String(), 'sync_status': 'pending'});
      await txn.insert('inventory_movements', {'product_id': productId, 'type': 'adjustment', 'quantity': quantityChange, 'reference_id': id, 'created_at': DateTime.now().toIso8601String()});
      await txn.insert('sync_queue', {'entity_type':'stock_adjustment','entity_id':id,'operation_type':'create','status':'pending','attempts':0});
      return id;
    });
  }

  Future<List<Map<String, dynamic>>> stockMovements() async {
    final db = await database;
    return db.rawQuery('''
      SELECT im.*, p.name AS product_name FROM inventory_movements im
      LEFT JOIN products p ON p.id = im.product_id
      ORDER BY im.id DESC LIMIT 100
    ''');
  }

  Future<Map<String, double>> profitSummary() async {
    final db = await database;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final sales = await db.rawQuery('''
      SELECT COALESCE(SUM(si.total),0) revenue,
             COALESCE(SUM(si.quantity * p.cost_price),0) cost
      FROM sale_items si JOIN products p ON p.id=si.product_id
      JOIN sales s ON s.id=si.sale_id
      WHERE substr(s.created_at,1,10)=?
    ''', [today]);
    final expenses = await db.rawQuery("SELECT COALESCE(SUM(amount),0) e FROM expenses WHERE substr(created_at,1,10)=?", [today]);
    final revenue=(sales.first['revenue'] as num?)?.toDouble() ?? 0;
    final cost=(sales.first['cost'] as num?)?.toDouble() ?? 0;
    final exp=(expenses.first['e'] as num?)?.toDouble() ?? 0;
    return {'revenue': revenue, 'cost': cost, 'expenses': exp, 'gross_profit': revenue-cost, 'net_profit': revenue-cost-exp};
  }

  Future<List<Map<String, dynamic>>> purchases() async {
    final db = await database;
    return db.query('purchases', orderBy: 'id DESC');
  }

  Future<double> purchasesTodayTotal() async {
    final db = await database;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final r = await db.rawQuery(
      "SELECT COALESCE(SUM(total),0) amount FROM purchases WHERE substr(created_at,1,10)=?",
      [today],
    );
    return (r.first['amount'] as num?)?.toDouble() ?? 0;
  }

  Future<List<Map<String, dynamic>>> supplierPayments(int supplierId) async {
    final db = await database;
    return db.query('supplier_payments', where: 'supplier_id = ?', whereArgs: [supplierId], orderBy: 'id DESC');
  }

  Future<double> supplierPaidTotal(int supplierId) async {
    final db = await database;
    final r = await db.rawQuery('SELECT COALESCE(SUM(amount),0) total FROM supplier_payments WHERE supplier_id=?', [supplierId]);
    return (r.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<int> addSupplierPayment({required int supplierId, required double amount, String? note}) async {
    if (amount <= 0) throw ArgumentError('amount must be positive');
    final db = await database;
    return db.transaction((txn) async {
      final row = await txn.query('suppliers', columns: ['balance'], where: 'id=?', whereArgs: [supplierId], limit: 1);
      if (row.isEmpty) throw StateError('supplier not found');
      final balance = (row.first['balance'] as num?)?.toDouble() ?? 0;
      if (amount > balance + 0.000001) throw StateError('payment exceeds supplier balance');
      final now = DateTime.now().toIso8601String();
      final uuid = '${supplierId}_${DateTime.now().microsecondsSinceEpoch}';
      final id = await txn.insert('supplier_payments', {
        'supplier_id': supplierId, 'amount': amount, 'note': note, 'created_at': now, 'sync_status': 'pending', 'local_uuid': uuid,
      });
      await txn.rawUpdate('UPDATE suppliers SET balance = balance - ? WHERE id = ?', [amount, supplierId]);
      await txn.insert('sync_queue', {'entity_type':'supplier_payment','entity_id':id,'operation_type':'create','status':'pending','attempts':0});
      await txn.insert('audit_logs', {'action':'supplier_payment','entity_type':'supplier','entity_id':supplierId,'details':'amount=$amount','created_at':now});
      return id;
    });
  }

  Future<List<Map<String, dynamic>>> purchaseItems(int purchaseId) async {
    final db = await database;
    return db.rawQuery('''SELECT pi.*, p.name AS product_name FROM purchase_items pi LEFT JOIN products p ON p.id=pi.product_id WHERE pi.purchase_id=? ORDER BY pi.id''', [purchaseId]);
  }

  Future<int> createPurchase({int? supplierId, required String localUuid, required String invoiceNumber, required List<Map<String,dynamic>> items, required double total, required double paidAmount, required String paymentMethod}) async {
    final db = await database;
    return db.transaction((txn) async {
      final now=DateTime.now().toIso8601String();
      final id=await txn.insert('purchases', {'supplier_id':supplierId,'local_uuid':localUuid,'invoice_number':invoiceNumber,'subtotal':total,'paid_amount':paidAmount,'total':total,'payment_method':paymentMethod,'sync_status':'pending','created_at':now});
      for(final item in items){
        final qty=(item['qty'] as num).toDouble();
        final cost=(item['cost'] as num).toDouble();
        final pid=item['product_id'] as int;
        await txn.insert('purchase_items', {'purchase_id':id,'product_id':pid,'quantity':qty,'unit_cost':cost,'total':qty*cost});
        await txn.rawUpdate('UPDATE products SET quantity=quantity+?, cost_price=? WHERE id=?',[qty,cost,pid]);
        await txn.insert('inventory_movements', {'product_id':pid,'type':'purchase','quantity':qty,'reference_id':id,'created_at':now});
      }
      if (supplierId != null) {
        final outstanding = total - paidAmount;
        if (outstanding != 0) {
          await txn.rawUpdate('UPDATE suppliers SET balance = balance + ? WHERE id = ?', [outstanding, supplierId]);
        }
      }
      await txn.insert('sync_queue', {'entity_type':'purchase','entity_id':id,'operation_type':'create','status':'pending','attempts':0});
      return id;
    });
  }

  Future<List<Map<String, dynamic>>> salesForReturns({String? query}) async {
    final db = await database;
    if (query == null || query.trim().isEmpty) return db.query('sales', orderBy: 'id DESC', limit: 100);
    final q = query.trim();
    return db.query('sales', where: 'invoice_number LIKE ? OR customer_name LIKE ?', whereArgs: ['%$q%', '%$q%'], orderBy: 'id DESC', limit: 100);
  }

  Future<List<Map<String, dynamic>>> saleItemsForReturn(int saleId) async {
    final db = await database;
    return db.rawQuery('SELECT si.*, p.quantity AS stock_quantity, COALESCE((SELECT SUM(ri.quantity) FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.sale_id=? AND ri.product_id=si.product_id),0) AS returned_quantity FROM sale_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id', [saleId, saleId]);
  }

  Future<int> createReturn({required String localUuid, int? saleId, String? invoiceNumber, required List<Map<String,dynamic>> items, required double total, String? reason}) async {
    if (items.isEmpty || total <= 0) throw ArgumentError('return items required');
    final db = await database;
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      Map<String, dynamic>? sale;
      if (saleId != null) {
        final rows = await txn.query('sales', where: 'id=?', whereArgs: [saleId], limit: 1);
        if (rows.isEmpty) throw StateError('فاتورة البيع غير موجودة');
        sale = rows.first;
      }
      final rid = await txn.insert('returns', {'local_uuid': localUuid, 'sale_id': saleId, 'invoice_number': invoiceNumber, 'total': total, 'reason': reason, 'sync_status': 'pending', 'created_at': now});
      for (final item in items) {
        final qty = (item['qty'] as num).toDouble();
        final pid = item['product_id'] as int;
        final price = (item['price'] as num).toDouble();
        if (qty <= 0) throw StateError('كمية المرتجع غير صحيحة');
        if (saleId != null) {
          final soldRows = await txn.rawQuery('SELECT COALESCE(SUM(quantity),0) q FROM sale_items WHERE sale_id=? AND product_id=?', [saleId, pid]);
          final returnedRows = await txn.rawQuery('SELECT COALESCE(SUM(ri.quantity),0) q FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.sale_id=? AND ri.product_id=?', [saleId, pid]);
          final sold = (soldRows.first['q'] as num?)?.toDouble() ?? 0;
          final returned = (returnedRows.first['q'] as num?)?.toDouble() ?? 0;
          if (qty > sold - returned + 0.000001) throw StateError('الكمية المرتجعة أكبر من الكمية المباعة المتبقية');
        }
        await txn.insert('return_items', {'return_id': rid, 'product_id': pid, 'quantity': qty, 'unit_price': price, 'total': qty * price});
        await txn.rawUpdate('UPDATE products SET quantity=quantity+? WHERE id=?', [qty, pid]);
        await txn.insert('inventory_movements', {'product_id': pid, 'type': 'return', 'quantity': qty, 'reference_id': rid, 'created_at': now});
      }
      if (saleId != null && sale != null && sale['customer_id'] != null && sale['payment_method'] == 'آجل') {
        final customerId = sale['customer_id'] as int;
        final refundableCredit = total.clamp(0, ((sale['total'] as num).toDouble() - (sale['paid_amount'] as num).toDouble()));
        if (refundableCredit > 0) {
          await txn.rawUpdate('UPDATE customers SET balance = MAX(balance - ?, 0) WHERE id=?', [refundableCredit, customerId]);
          await txn.insert('sync_queue', {'entity_type':'customer','entity_id':customerId,'operation_type':'update','status':'pending','attempts':0});
        }
      }
      await txn.insert('audit_logs', {'action':'create','entity_type':'return','entity_id':rid,'details':'total=$total invoice=${invoiceNumber ?? ''}','created_at':now});
      await txn.insert('sync_queue', {'entity_type':'return','entity_id':rid,'operation_type':'create','status':'pending','attempts':0});
      return rid;
    });
  }

}