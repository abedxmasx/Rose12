import 'dart:async';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(image: AssetImage('assets/rose12_logo.png'), width: 280),
            SizedBox(height: 24),
            Text('Sales & Management',
                style: TextStyle(color: Color(0xFF2C668F), fontSize: 18)),
            SizedBox(height: 8),
            Text('إدارة أسهل .. لمستقبل أفضل',
                style: TextStyle(color: Color(0xFFC79A55), fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
