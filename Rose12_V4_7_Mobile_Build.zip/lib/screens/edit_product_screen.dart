import 'package:flutter/material.dart';
import '../database/app_database.dart';

class EditProductScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  const EditProductScreen({super.key, required this.product});
  @override
  State<EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  late final TextEditingController name;
  late final TextEditingController category;
  late final TextEditingController unit;
  late final TextEditingController cost;
  late final TextEditingController price;
  late final TextEditingController wholesale;
  late final TextEditingController minStock;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    name = TextEditingController(text: '${p['name'] ?? ''}');
    category = TextEditingController(text: '${p['category'] ?? ''}');
    unit = TextEditingController(text: '${p['unit'] ?? 'قطعة'}');
    cost = TextEditingController(text: '${p['cost_price'] ?? 0}');
    price = TextEditingController(text: '${p['sale_price'] ?? 0}');
    wholesale = TextEditingController(text: '${p['wholesale_price'] ?? 0}');
    minStock = TextEditingController(text: '${p['min_stock'] ?? 0}');
  }

  @override
  void dispose() { for (final c in [name, category, unit, cost, price, wholesale, minStock]) { c.dispose(); } super.dispose(); }

  Future<void> _save() async {
    if (name.text.trim().isEmpty || double.tryParse(price.text) == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اسم المنتج وسعر البيع مطلوبان')));
      return;
    }
    await AppDatabase.instance.updateProduct(widget.product['id'] as int, {
      'name': name.text.trim(),
      'category': category.text.trim(),
      'unit': unit.text.trim().isEmpty ? 'قطعة' : unit.text.trim(),
      'cost_price': double.tryParse(cost.text) ?? 0,
      'sale_price': double.tryParse(price.text) ?? 0,
      'wholesale_price': double.tryParse(wholesale.text) ?? 0,
      'min_stock': double.tryParse(minStock.text) ?? 0,
    });
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تعديل المنتج')),
    body: Directionality(textDirection: TextDirection.rtl, child: ListView(padding: const EdgeInsets.all(16), children: [
      _field(name, 'اسم المنتج', Icons.inventory_2_outlined),
      _field(category, 'التصنيف', Icons.category_outlined),
      _field(unit, 'الوحدة', Icons.straighten_outlined),
      Row(children: [
        Expanded(child: _field(cost, 'سعر التكلفة', Icons.price_change_outlined, number: true)),
        const SizedBox(width: 10),
        Expanded(child: _field(price, 'سعر البيع', Icons.sell_outlined, number: true)),
      ]),
      _field(wholesale, 'سعر الجملة', Icons.storefront_outlined, number: true),
      _field(minStock, 'حد إعادة الطلب', Icons.warning_amber_outlined, number: true),
      const SizedBox(height: 8),
      Text('المخزون الحالي: ${widget.product['quantity']} ${widget.product['unit'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      SizedBox(height: 52, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('حفظ التعديلات'))),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () => Navigator.pushNamed(context, '/product-price-history', arguments: widget.product),
        icon: const Icon(Icons.history),
        label: const Text('سجل تغييرات الأسعار'),
      ),
    ])),
  );

  Widget _field(TextEditingController c, String label, IconData icon, {bool number = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon))),
  );
}
