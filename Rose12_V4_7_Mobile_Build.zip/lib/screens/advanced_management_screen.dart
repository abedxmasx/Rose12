
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../database/app_database.dart';

class AdvancedManagementScreen extends StatefulWidget {
  const AdvancedManagementScreen({super.key});
  @override State<AdvancedManagementScreen> createState()=>_AdvancedManagementScreenState();
}
class _AdvancedManagementScreenState extends State<AdvancedManagementScreen>{
  int tab=0;
  final tabs=['المخزون','الموردون','الموظفون','المشتريات','المرتجعات'];
  List<Map<String,dynamic>> products=[], suppliers=[], staff=[], purchases=[], movements=[];
  final TextEditingController stockSearch=TextEditingController();
  String movementFilter='الكل';
  final TextEditingController returnSearch=TextEditingController();
  List<Map<String,dynamic>> returnSales=[];
  Map<String,dynamic>? selectedReturnSale;
  List<Map<String,dynamic>> returnItems=[];
  Future<void> load() async {
    final db=AppDatabase.instance;
    final a=await db.products(), b=await db.suppliers(), c=await db.staff(), d=await db.purchases(), e=await db.stockMovements();
    if(mounted)setState(()=>{products=a,suppliers=b,staff=c,purchases=d,movements=e});
  }
  @override void initState(){super.initState();load();loadReturnSales();}
  @override void dispose(){stockSearch.dispose();returnSearch.dispose();super.dispose();}
  String movementLabel(String t){switch(t){case 'sale':return 'بيع';case 'purchase':return 'شراء';case 'return':return 'مرتجع';case 'adjustment':return 'تعديل';default:return t;}}
  List<Map<String,dynamic>> get filteredProducts { final q=stockSearch.text.trim().toLowerCase(); return products.where((p)=>q.isEmpty||'${p['name']}'.toLowerCase().contains(q)).toList(); }
  List<Map<String,dynamic>> get filteredMovements { if(movementFilter=='الكل') return movements; final key={'بيع':'sale','شراء':'purchase','مرتجع':'return','تعديل':'adjustment'}[movementFilter]; return movements.where((m)=>m['type']==key).toList(); }
  Future<void> addSupplier() async {
    final n=TextEditingController(), p=TextEditingController(), a=TextEditingController();
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إضافة مورد'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'اسم المورد')),TextField(controller:p,decoration:const InputDecoration(labelText:'الهاتف')),TextField(controller:a,decoration:const InputDecoration(labelText:'العنوان'))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()async{if(n.text.trim().isNotEmpty){await AppDatabase.instance.addSupplier(name:n.text.trim(),phone:p.text,address:a.text);if(mounted)Navigator.pop(context);load();}},child:const Text('حفظ'))]));
  }
  Future<void> addStaff() async {
    final n=TextEditingController(), u=TextEditingController(); String role='موظف';
    await showDialog(context:context,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('إضافة موظف'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'الاسم')),TextField(controller:u,decoration:const InputDecoration(labelText:'اسم المستخدم')),
      DropdownButton<String>(value:role,items:['موظف','مدير','مشرف'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>set(()=>role=x!))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{if(n.text.trim().isNotEmpty&&u.text.trim().isNotEmpty){await AppDatabase.instance.addStaff(name:n.text.trim(),username:u.text.trim(),role:role);if(mounted)Navigator.pop(c);load();}},child:const Text('حفظ'))])));
  }
  Future<void> supplierAccount(Map<String,dynamic> supplier) async {
    final balance = (supplier['balance'] as num?)?.toDouble() ?? 0;
    final payments = await AppDatabase.instance.supplierPayments(supplier['id'] as int);
    if (!mounted) return;
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text('حساب المورد: ${supplier['name']}'),
      content: SizedBox(width: 500, child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('الرصيد المستحق: ${balance.toStringAsFixed(2)} د.أ', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        if (payments.isEmpty) const Text('لا توجد دفعات مسجلة.'),
        ...payments.map((x) => ListTile(dense: true, leading: const Icon(Icons.payments_outlined), title: Text('${x['amount']} د.أ'), subtitle: Text('${x['created_at']}${(x['note'] ?? '').toString().isEmpty ? '' : ' — ${x['note']}'}'))),
      ]))),
      actions: [
        if (balance > 0) FilledButton.icon(onPressed: () async { Navigator.pop(ctx); await addSupplierPayment(supplier); }, icon: const Icon(Icons.payments), label: const Text('تسجيل دفعة')),
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
      ],
    ));
  }

  Future<void> addSupplierPayment(Map<String,dynamic> supplier) async {
    final amount = TextEditingController();
    final note = TextEditingController();
    final balance = (supplier['balance'] as num?)?.toDouble() ?? 0;
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text('دفعة للمورد: ${supplier['name']}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('الرصيد الحالي: ${balance.toStringAsFixed(2)} د.أ'),
        TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'مبلغ الدفعة')),
        TextField(controller: note, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final v = double.tryParse(amount.text.replaceAll(',', '.'));
          if (v == null || v <= 0 || v > balance + 0.000001) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل مبلغًا صحيحًا لا يتجاوز رصيد المورد')));
            return;
          }
          try {
            await AppDatabase.instance.addSupplierPayment(supplierId: supplier['id'] as int, amount: v, note: note.text.trim().isEmpty ? null : note.text.trim());
            if (mounted) Navigator.pop(ctx);
            await load();
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تسجيل الدفعة: $e')));
          }
        }, child: const Text('حفظ الدفعة')),
      ],
    ));
  }

  Future<void> purchaseDetails(Map<String,dynamic> purchase) async {
    final items = await AppDatabase.instance.purchaseItems(purchase['id'] as int);
    final suppliersList = suppliers.where((x) => x['id'] == purchase['supplier_id']).toList();
    final supplierName = suppliersList.isEmpty ? 'بدون مورد' : suppliersList.first['name'].toString();
    if (!mounted) return;
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text('فاتورة شراء ${purchase['invoice_number']}'),
      content: SizedBox(width: 520, child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('المورد: $supplierName'),
        Text('التاريخ: ${purchase['created_at']}'),
        Text('الدفع: ${purchase['payment_method'] == 'credit' ? 'آجل' : 'نقدي'}'),
        const Divider(),
        ...items.map((x) => ListTile(dense: true, title: Text('${x['product_name'] ?? 'منتج'}'), subtitle: Text('الكمية: ${x['quantity']} × ${x['unit_cost']} د.أ'), trailing: Text('${x['total']} د.أ'))),
        const Divider(),
        Text('الإجمالي: ${purchase['total']} د.أ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        Text('المدفوع: ${purchase['paid_amount']} د.أ'),
        Text('المتبقي: ${((purchase['total'] as num).toDouble() - (purchase['paid_amount'] as num).toDouble()).toStringAsFixed(2)} د.أ'),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
    ));
  }

  Future<void> adjust(Map<String,dynamic> p) async {
    final q=TextEditingController(); final reason=TextEditingController();
    await showDialog(context:context,builder:(_)=>AlertDialog(title:Text('تعديل مخزون: ${p['name']}'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:q,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'الكمية (+ للإضافة، - للخصم)')),TextField(controller:reason,decoration:const InputDecoration(labelText:'السبب'))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()async{final v=double.tryParse(q.text.replaceAll(',','.'));if(v!=null){await AppDatabase.instance.addStockAdjustment(productId:p['id'],quantityChange:v,reason:reason.text);if(mounted)Navigator.pop(context);load();}},child:const Text('حفظ'))]));
  }
  Future<void> addPurchase() async {
    final products = await AppDatabase.instance.products();
    final suppliers = await AppDatabase.instance.suppliers();
    final selected = <Map<String,dynamic>>[];
    int? supplierId;
    String payment='cash';
    final invoice=TextEditingController(text:'PUR-${DateTime.now().millisecondsSinceEpoch}');
    await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(
      title:const Text('شراء جديد'),
      content:SizedBox(width:520,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:invoice,decoration:const InputDecoration(labelText:'رقم فاتورة المورد')),
        DropdownButtonFormField<int?>(value:supplierId,decoration:const InputDecoration(labelText:'المورد (اختياري)'),items:[const DropdownMenuItem<int?>(value:null,child:Text('بدون مورد')), ...suppliers.map((x)=>DropdownMenuItem<int?>(value:x['id'] as int,child:Text(x['name'].toString())))],onChanged:(v)=>set(()=>supplierId=v)),
        DropdownButtonFormField<String>(value:payment,decoration:const InputDecoration(labelText:'طريقة الدفع'),items:const [DropdownMenuItem(value:'cash',child:Text('نقدي')),DropdownMenuItem(value:'credit',child:Text('آجل'))],onChanged:(v)=>set(()=>payment=v??'cash')),
        const SizedBox(height:8),
        ...products.map((p){
          final existing=selected.where((x)=>x['product_id']==p['id']).toList();
          final q=existing.isEmpty?0.0:(existing.first['qty'] as double);
          final c=existing.isEmpty?(p['cost_price'] as num).toDouble():(existing.first['cost'] as double);
          return Card(child:Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:Text('${p['name']}\nتكلفة: $c د.أ')),SizedBox(width:70,child:TextFormField(initialValue:q==0?'':q.toString(),keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'كمية'),onChanged:(v){final val=double.tryParse(v.replaceAll(',','.'))??0;selected.removeWhere((x)=>x['product_id']==p['id']);if(val>0)selected.add({'product_id':p['id'],'qty':val,'cost':c});set((){});})),])),);
        }),
        const SizedBox(height:8),
        Builder(builder:(_){final total=selected.fold<double>(0,(a,x)=>a+(x['qty'] as double)*(x['cost'] as double));return Align(alignment:Alignment.centerRight,child:Text('الإجمالي: ${total.toStringAsFixed(2)} د.أ',style:const TextStyle(fontWeight:FontWeight.bold)));}),
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()async{
        if(selected.isEmpty){return;}
        final total=selected.fold<double>(0,(a,x)=>a+(x['qty'] as double)*(x['cost'] as double));
        final paid=payment=='cash'?total:0;
        await AppDatabase.instance.createPurchase(supplierId:supplierId,localUuid:const Uuid().v4(),invoiceNumber:invoice.text.trim().isEmpty?'PUR-${DateTime.now().millisecondsSinceEpoch}':invoice.text.trim(),items:selected,total:total,paidAmount:paid,paymentMethod:payment);
        if(mounted)Navigator.pop(ctx);load();
      },child:const Text('حفظ الشراء'))]
    )));
  }
  Future<void> loadReturnSales() async {
    final rows = await AppDatabase.instance.salesForReturns(query: returnSearch.text);
    if (mounted) setState(() => returnSales = rows);
  }

  Future<void> selectReturnSale(Map<String,dynamic> sale) async {
    final items = await AppDatabase.instance.saleItemsForReturn(sale['id'] as int);
    if (mounted) setState(() { selectedReturnSale = sale; returnItems = items; });
  }

  Future<void> saveReturn() async {
    final sale = selectedReturnSale;
    if (sale == null) return;
    final selected = returnItems.where((x) => ((x['return_qty'] as num?)?.toDouble() ?? 0) > 0).map((x) => {
      'product_id': x['product_id'] as int,
      'qty': (x['return_qty'] as num).toDouble(),
      'price': (x['unit_price'] as num).toDouble(),
    }).toList();
    final total = selected.fold<double>(0, (a, x) => a + (x['qty'] as double) * (x['price'] as double));
    if (selected.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حدد كمية واحدة على الأقل')));
      return;
    }
    final reason = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text('تأكيد مرتجع ${sale['invoice_number']}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('قيمة المرتجع: ${total.toStringAsFixed(2)} د.أ'),
        TextField(controller: reason, decoration: const InputDecoration(labelText: 'سبب المرتجع (اختياري)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد المرتجع'))],
    ));
    if (ok != true) return;
    try {
      await AppDatabase.instance.createReturn(localUuid: const Uuid().v4(), saleId: sale['id'] as int, invoiceNumber: sale['invoice_number']?.toString(), items: selected, total: total, reason: reason.text.trim().isEmpty ? null : reason.text.trim());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل المرتجع وتحديث المخزون')));
      setState(() { selectedReturnSale = null; returnItems = []; });
      await load();
      await loadReturnSales();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تسجيل المرتجع: $e')));
    }
  }

  Widget returnsBody() {
    if (selectedReturnSale == null) {
      return ListView(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(controller: returnSearch, onChanged: (_) => loadReturnSales(), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'ابحث برقم الفاتورة أو اسم العميل', border: OutlineInputBorder()))),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('اختر فاتورة البيع لعمل المرتجع', style: TextStyle(fontWeight: FontWeight.bold))),
        ...returnSales.map((s) => Card(child: ListTile(onTap: () => selectReturnSale(s), leading: const CircleAvatar(child: Icon(Icons.receipt_long)), title: Text('${s['invoice_number']}'), subtitle: Text('${s['customer_name'] ?? 'عميل نقدي'} | ${s['created_at']} | ${s['payment_method']}'), trailing: Text('${s['total']} د.أ')))),
      ]);
    }
    final sale = selectedReturnSale!;
    return ListView(children: [
      Padding(padding: const EdgeInsets.all(12), child: Card(child: ListTile(leading: const Icon(Icons.receipt_long), title: Text('فاتورة ${sale['invoice_number']}'), subtitle: Text('${sale['customer_name'] ?? 'عميل نقدي'} | الإجمالي ${sale['total']} د.أ'), trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { selectedReturnSale = null; returnItems = []; }))))),
      ...returnItems.map((x) {
        final sold = (x['quantity'] as num).toDouble();
        final already = (x['returned_quantity'] as num?)?.toDouble() ?? 0;
        final remaining = sold - already;
        final controller = TextEditingController(text: ((x['return_qty'] as num?)?.toDouble() ?? 0) == 0 ? '' : '${x['return_qty']}');
        return Card(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
          Expanded(child: Text('${x['product_name'] ?? 'منتج'}\nمباع: $sold | مرتجع سابق: $already | المتبقي: $remaining\nالسعر: ${x['unit_price']} د.أ')),
          SizedBox(width: 85, child: TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'مرتجع'), onChanged: (v) {
            final q = double.tryParse(v.replaceAll(',', '.')) ?? 0;
            if (q <= remaining) { setState(() => x['return_qty'] = q); }
          })),
        ])));
      }),
      Padding(padding: const EdgeInsets.all(12), child: FilledButton.icon(onPressed: saveReturn, icon: const Icon(Icons.assignment_return), label: const Text('تسجيل المرتجع'))),
    ]);
  }

  Widget body(){
    if(tab==0)return ListView(children:[
      Padding(padding:const EdgeInsets.all(12),child:TextField(controller:stockSearch,onChanged:(_){setState((){});},decoration:const InputDecoration(prefixIcon:Icon(Icons.search),labelText:'بحث عن المنتج بالاسم فقط',border:OutlineInputBorder()))),
      Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:Wrap(spacing:8,runSpacing:8,children:[
        Chip(label:Text('المنتجات: ${products.length}')),
        Chip(label:Text('منخفض المخزون: ${products.where((p)=>(p['quantity'] as num) <= (p['min_stock'] as num)).length}')),
        Chip(label:Text('حركات: ${movements.length}')),
      ])),
      ...filteredProducts.map((p){final low=(p['quantity'] as num) <= (p['min_stock'] as num); return Card(child:ListTile(title:Text(p['name']),subtitle:Text('المتوفر: ${p['quantity']} ${p['unit']} | الحد الأدنى: ${p['min_stock']}'+(low?' | مخزون منخفض':'')),trailing:IconButton(icon:const Icon(Icons.tune),onPressed:()=>adjust(p))));}),
      const Divider(),
      Padding(padding:const EdgeInsets.all(12),child:Row(children:[const Expanded(child:Text('حركات المخزون',style:TextStyle(fontWeight:FontWeight.bold))),DropdownButton<String>(value:movementFilter,items:['الكل','بيع','شراء','مرتجع','تعديل'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x){if(x!=null)setState(()=>movementFilter=x);})])),
      ...filteredMovements.take(50).map((m)=>ListTile(dense:true,title:Text('${m['product_name']??''}'),subtitle:Text('${movementLabel('${m['type']}')} — ${m['created_at']}'),trailing:Text('${m['quantity']}'))),
    ]);
    if(tab==1)return ListView(children:[
      Padding(padding:const EdgeInsets.all(12),child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Text('اضغط على المورد لعرض الحساب وتسجيل دفعة.',style:TextStyle(color:Colors.grey[700]))))),
      ...suppliers.map((x)=>Card(child:ListTile(onTap:()=>supplierAccount(x),leading:const CircleAvatar(child:Icon(Icons.local_shipping_outlined)),title:Text(x['name']),subtitle:Text('${x['phone']??''} | الرصيد المستحق: ${((x['balance'] as num?)?.toDouble()??0).toStringAsFixed(2)} د.أ'),trailing:const Icon(Icons.chevron_left))))
    ]);
    if(tab==2)return ListView(children:[...staff.map((x)=>ListTile(title:Text(x['name']),subtitle:Text('@${x['username']}'),trailing:Text(x['role'])) )]);
    if(tab==3)return ListView(children:[
      Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        FilledButton.icon(onPressed:addPurchase,icon:const Icon(Icons.add_shopping_cart),label:const Text('إنشاء فاتورة شراء')),
        const SizedBox(height:8),
        Text('عدد فواتير الشراء: ${purchases.length}',style:const TextStyle(fontWeight:FontWeight.bold)),
      ])),
      ...purchases.map((x)=>Card(child:ListTile(onTap:()=>purchaseDetails(x),leading:const CircleAvatar(child:Icon(Icons.receipt_long)),title:Text('فاتورة شراء ${x['invoice_number']}'),subtitle:Text('${x['created_at']} | ${x['payment_method']=='credit'?'آجل':'نقدي'} | مدفوع: ${x['paid_amount']} د.أ'),trailing:Text('${x['total']} د.أ',style:const TextStyle(fontWeight:FontWeight.bold))))),
    ]);
    return returnsBody();
  }
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('الإدارة المتقدمة')),body:Column(children:[
    SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:List.generate(tabs.length,(i)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(tabs[i]),selected:tab==i,onSelected:(_){setState(()=>tab=i);}))))),
    Expanded(child:body())
  ]),floatingActionButton:(tab==1||tab==2)?FloatingActionButton.extended(onPressed:tab==1?addSupplier:addStaff,icon:const Icon(Icons.add),label:Text(tab==1?'مورد جديد':'موظف جديد')):null));
}
