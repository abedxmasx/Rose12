import 'package:flutter/material.dart';
import '../services/supervisor_service.dart';

class SupervisorDashboardScreen extends StatefulWidget {
  const SupervisorDashboardScreen({super.key});
  @override State<SupervisorDashboardScreen> createState() => _SupervisorDashboardScreenState();
}

class _SupervisorDashboardScreenState extends State<SupervisorDashboardScreen> with SingleTickerProviderStateMixin {
  Map<String, dynamic>? data;
  List<Map<String, dynamic>> rows = [];
  List<Map<String, dynamic>> devices = [];
  List<Map<String, dynamic>> audits = [];
  bool busy = true;
  late final TabController tabs = TabController(length: 3, vsync: this);

  @override void initState() { super.initState(); load(); }
  @override void dispose() { tabs.dispose(); super.dispose(); }

  Future<void> load() async {
    if (mounted) setState(() => busy = true);
    try {
      final s = await SupervisorService.instance.summary();
      final r = await SupervisorService.instance.sales();
      final d = await SupervisorService.instance.devices();
      final a = await SupervisorService.instance.auditLogs();
      if (mounted) setState(() { data = s; rows = r; devices = d; audits = a; busy = false; });
    } catch (_) {
      if (mounted) setState(() => busy = false);
    }
  }

  String money(dynamic v) => '${(v as num?)?.toStringAsFixed(2) ?? '0.00'} د.أ';
  String text(dynamic v) => v?.toString() ?? '';

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مركز ${SupervisorService.instance.name ?? 'المشرف'}'),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh), tooltip: 'تحديث'),
          IconButton(onPressed: () => Navigator.pushNamed(context, '/devices'), icon: const Icon(Icons.devices), tooltip: 'الأجهزة'),
        ],
        bottom: TabBar(controller: tabs, tabs: const [Tab(text: 'الرئيسية'), Tab(text: 'الفواتير'), Tab(text: 'الأجهزة')]),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: RefreshIndicator(
          onRefresh: load,
          child: TabBarView(controller: tabs, children: [_home(), _sales(), _devices()]),
        ),
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(16), children: [
    if (busy) const LinearProgressIndicator(),
    const Text('ملخص المبيعات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.45,
      children: [
        _card('مبيعات اليوم', money(data?['today_amount']), Icons.today),
        _card('فواتير اليوم', text(data?['today_count'] ?? 0), Icons.receipt_long),
        _card('إجمالي المبيعات', money(data?['total_amount']), Icons.bar_chart),
        _card('عدد الفواتير', text(data?['total_sales'] ?? 0), Icons.analytics),
      ]),
    const SizedBox(height: 22),
    Card(child: ListTile(leading: const Icon(Icons.sync), title: const Text('آخر تحديث'), subtitle: Text(DateTime.now().toString().substring(0, 19)))),
    const SizedBox(height: 12),
    if (audits.isNotEmpty) ...[
      const Text('آخر نشاط', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...audits.take(8).map((x) => Card(child: ListTile(leading: const Icon(Icons.history), title: Text(text(x['action'] ?? 'نشاط')), subtitle: Text('${text(x['entity_type'])} • ${text(x['created_at'])}')))),
    ] else const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('لا توجد سجلات نشاط متاحة')),
  ]);

  Widget _sales() => ListView(padding: const EdgeInsets.all(16), children: [
    if (busy) const LinearProgressIndicator(),
    Text('الفواتير (${rows.length})', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    if (rows.isEmpty) const Card(child: ListTile(title: Text('لا توجد فواتير'))),
    ...rows.take(100).map((x) => Card(child: ListTile(
      leading: CircleAvatar(child: Text(text(x['id']))),
      title: Text('فاتورة ${text(x['invoice_number'])}'),
      subtitle: Text('${text(x['payment_method'])} • ${text(x['created_at'])}'),
      trailing: Text(money(x['total']), style: const TextStyle(fontWeight: FontWeight.bold)),
    ))),
  ]);

  Widget _devices() => ListView(padding: const EdgeInsets.all(16), children: [
    if (busy) const LinearProgressIndicator(),
    Text('الأجهزة (${devices.length})', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    if (devices.isEmpty) const Card(child: ListTile(title: Text('لا توجد أجهزة مسجلة'))),
    ...devices.map((d) {
      final id = d['id'];
      final active = d['active'] == true || d['active'] == 1;
      return Card(child: ListTile(
        leading: Icon(active ? Icons.phone_android : Icons.block, color: active ? Colors.green : Colors.red),
        title: Text(text(d['name']).isEmpty ? 'جهاز بدون اسم' : text(d['name'])),
        subtitle: Text('المفتاح: ${text(d['device_key'])}\nالحالة: ${active ? 'فعال' : 'متوقف'}'),
        isThreeLine: true,
        trailing: Switch(value: active, onChanged: id == null ? null : (v) async {
          final ok = await SupervisorService.instance.setDeviceActive(id is int ? id : int.parse(id.toString()), v);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم تحديث حالة الجهاز' : 'تعذر تحديث الجهاز')));
          if (ok) load();
        }),
      ));
    }),
  ]);

  Widget _card(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: const Color(0xFF2C668F)), const Spacer(), Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(color: Colors.grey)),
  ])));
}
