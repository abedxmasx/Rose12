import 'package:flutter/material.dart';
import '../database/app_database.dart';
import 'edit_product_screen.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  List<Map<String, dynamic>> items = [];
  String query = '';
  String category = 'الكل';
  bool lowOnly = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final data = await AppDatabase.instance.products();
    if (mounted) setState(() => items = data);
  }

  List<String> get categories {
    final values = items.map((p) => '${p['category'] ?? ''}'.trim()).where((x) => x.isNotEmpty).toSet().toList()..sort();
    return ['الكل', ...values];
  }

  List<Map<String, dynamic>> get filtered {
    final q = query.trim().toLowerCase();
    return items.where((p) {
      final name = '${p['name'] ?? ''}'.toLowerCase();
      final cat = '${p['category'] ?? ''}'.trim();
      final low = (p['quantity'] as num? ?? 0) <= (p['min_stock'] as num? ?? 0);
      return (q.isEmpty || name.contains(q)) && (category == 'الكل' || cat == category) && (!lowOnly || low);
    }).toList();
  }

  Future<void> _edit(Map<String, dynamic> p) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => EditProductScreen(product: p)));
    _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المنتجات'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
    body: Directionality(textDirection: TextDirection.rtl, child: RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(14), children: [
        TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث باسم المنتج فقط'), onChanged: (v) => setState(() => query = v)),
        const SizedBox(height: 10),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: categories.map((c) => Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c))).toList())),
        const SizedBox(height: 8),
        Row(children: [FilterChip(label: const Text('منخفض المخزون'), selected: lowOnly, onSelected: (v) => setState(() => lowOnly = v)), const SizedBox(width: 8), Text('${filtered.length} منتج')]),
        const SizedBox(height: 10),
        if (filtered.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد منتجات مطابقة'))),
        ...filtered.map((p) {
          final low = (p['quantity'] as num? ?? 0) <= (p['min_stock'] as num? ?? 0);
          return Card(child: ListTile(
            leading: CircleAvatar(child: Icon(low ? Icons.warning_amber : Icons.inventory_2_outlined)),
            title: Text('${p['name']}'),
            subtitle: Text('${p['category'] ?? 'بدون تصنيف'}  •  المخزون: ${p['quantity']} ${p['unit'] ?? ''}\nالحد الأدنى: ${p['min_stock'] ?? 0}'),
            isThreeLine: true,
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('${(p['sale_price'] as num).toStringAsFixed(2)} د.أ'), const SizedBox(height: 4), TextButton(onPressed: () => _edit(p), child: const Text('تعديل'))]),
          ));
        }),
      ],),
    )),
    floatingActionButton: FloatingActionButton.extended(onPressed: () async { await Navigator.pushNamed(context, '/add-product'); _load(); }, icon: const Icon(Icons.add), label: const Text('منتج جديد')),
  );
}
