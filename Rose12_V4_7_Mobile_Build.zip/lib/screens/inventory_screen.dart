import 'package:flutter/material.dart';
import '../database/app_database.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});
  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> movements = [];
  String query = '';
  bool lowOnly = false;
  bool loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => loading = true);
    final ps = lowOnly
        ? await AppDatabase.instance.lowStockProducts()
        : await AppDatabase.instance.products();
    final ms = await AppDatabase.instance.stockMovements();
    if (!mounted) return;
    setState(() { products = ps; movements = ms; loading = false; });
  }

  List<Map<String, dynamic>> get filtered {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return products;
    return products.where((p) => (p['name'] ?? '').toString().toLowerCase().contains(q)).toList();
  }

  Future<void> _adjust(Map<String, dynamic> p) async {
    final amount = TextEditingController();
    final reason = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('تعديل مخزون: ${p['name']}'),
        content: Directionality(
          textDirection: TextDirection.rtl,
          child: Form(key: formKey, child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('المخزون الحالي: ${p['quantity']} ${p['unit']}'),
            const SizedBox(height: 12),
            TextFormField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'التغيير (+ إضافة / - خصم)'), validator: (v) => double.tryParse(v ?? '') == null ? 'أدخل رقمًا صحيحًا' : null),
            const SizedBox(height: 10),
            TextField(controller: reason, decoration: const InputDecoration(labelText: 'سبب التعديل (اختياري)')),
          ])),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(context, true); }, child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true) return;
    final delta = double.parse(amount.text);
    final current = (p['quantity'] as num).toDouble();
    if (current + delta < 0) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا يمكن أن يصبح المخزون سالبًا')));
      return;
    }
    await AppDatabase.instance.addStockAdjustment(productId: p['id'] as int, quantityChange: delta, reason: reason.text.trim().isEmpty ? null : reason.text.trim());
    await _load();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تحديث المخزون')));
  }

  String _movementType(String type) {
    switch (type) { case 'sale': return 'بيع'; case 'purchase': return 'شراء'; case 'return': return 'مرتجع'; case 'adjustment': return 'تعديل'; default: return type; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة المخزون'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
      body: Directionality(textDirection: TextDirection.rtl, child: loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(14), children: [
            TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث باسم المنتج فقط'), onChanged: (v) => setState(() => query = v)),
            const SizedBox(height: 10),
            Row(children: [
              FilterChip(label: const Text('منخفض المخزون فقط'), selected: lowOnly, onSelected: (v) { setState(() => lowOnly = v); _load(); }),
              const SizedBox(width: 8),
              Text('${filtered.length} منتج', style: const TextStyle(color: Colors.grey)),
            ]),
            const SizedBox(height: 10),
            ...filtered.map((p) => Card(child: ListTile(
              leading: CircleAvatar(child: Icon((p['quantity'] as num) <= (p['min_stock'] as num) ? Icons.warning_amber : Icons.inventory_2_outlined)),
              title: Text(p['name'] as String),
              subtitle: Text('المخزون: ${p['quantity']} ${p['unit']}  •  الحد الأدنى: ${p['min_stock']}'),
              trailing: OutlinedButton(onPressed: () => _adjust(p), child: const Text('تعديل')),
            ))),
            const SizedBox(height: 18),
            const Text('آخر حركات المخزون', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...movements.take(30).map((m) => ListTile(
              dense: true,
              leading: const Icon(Icons.swap_vert),
              title: Text('${m['product_name'] ?? 'منتج'} — ${_movementType((m['type'] ?? '').toString())}'),
              subtitle: Text('${m['created_at'] ?? ''}'),
              trailing: Text('${m['quantity']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            )),
          ])),
    );
  }
}
