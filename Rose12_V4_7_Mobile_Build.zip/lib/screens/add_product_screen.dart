import 'package:flutter/material.dart';
import '../database/app_database.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final name = TextEditingController();
  final price = TextEditingController();
  final cost = TextEditingController();
  final quantity = TextEditingController();
  final barcode = TextEditingController();

  @override
  void dispose() {
    name.dispose();
    price.dispose();
    cost.dispose();
    quantity.dispose();
    barcode.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (name.text.trim().isEmpty || price.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اسم المنتج وسعر البيع مطلوبان')),
      );
      return;
    }
    await AppDatabase.instance.addProduct({
      'name': name.text.trim(),
      'sku': '',
      'barcode': barcode.text.trim(),
      'category': '',
      'unit': 'قطعة',
      'cost_price': double.tryParse(cost.text) ?? 0,
      'sale_price': double.tryParse(price.text) ?? 0,
      'wholesale_price': 0,
      'quantity': double.tryParse(quantity.text) ?? 0,
      'min_stock': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة منتج')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field(name, 'اسم المنتج', Icons.inventory_2_outlined),
            _field(barcode, 'الباركود', Icons.qr_code_2),
            Row(children: [
              Expanded(child: _field(cost, 'سعر التكلفة', Icons.price_change_outlined, number: true)),
              const SizedBox(width: 10),
              Expanded(child: _field(price, 'سعر البيع', Icons.sell_outlined, number: true)),
            ]),
            _field(quantity, 'الكمية الافتتاحية', Icons.numbers, number: true),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save_outlined),
                label: const Text('حفظ المنتج'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool number = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        keyboardType: number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      ),
    );
  }
}
