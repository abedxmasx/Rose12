import 'package:flutter/material.dart';
import '../services/supervisor_service.dart';

class SupervisorLoginScreen extends StatefulWidget { const SupervisorLoginScreen({super.key});
  @override State<SupervisorLoginScreen> createState()=>_SupervisorLoginScreenState(); }
class _SupervisorLoginScreenState extends State<SupervisorLoginScreen>{
  final u=TextEditingController(text:'supervisor1'), p=TextEditingController(text:'Rose12@123'); bool busy=false;
  Future<void> login() async { setState(()=>busy=true); try { final ok=await SupervisorService.instance.login(u.text.trim(),p.text); if(!mounted)return; if(ok) Navigator.pushReplacementNamed(context,'/supervisor'); else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('بيانات الدخول غير صحيحة أو الخادم غير متاح'))); } catch(e){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر الاتصال بالخادم'))); } finally { if(mounted)setState(()=>busy=false); } }
  @override Widget build(BuildContext c)=>Scaffold(body:Directionality(textDirection:TextDirection.rtl,child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[Icon(Icons.admin_panel_settings,size:70,color:Color(0xFF2C668F)),SizedBox(height:12),Text('لوحة المشرفين',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),SizedBox(height:24),TextField(controller:u,decoration:InputDecoration(labelText:'اسم المستخدم',prefixIcon:Icon(Icons.person))),SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:InputDecoration(labelText:'كلمة المرور',prefixIcon:Icon(Icons.lock))),SizedBox(height:20),SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:busy?null:login,child:busy?const CircularProgressIndicator():const Text('دخول')))])))))));
}
