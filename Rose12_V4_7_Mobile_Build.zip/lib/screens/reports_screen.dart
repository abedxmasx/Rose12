import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../database/app_database.dart';
import '../services/report_export_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> with SingleTickerProviderStateMixin {
  DateTime from = DateTime.now();
  DateTime to = DateTime.now();
  bool loading = true;
  late final TabController tabs = TabController(length: 4, vsync: this);

  Map<String, double> totals = {};
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> expenseCategories = [];
  List<Map<String, dynamic>> lowStock = [];

  String day(DateTime d) => d.toIso8601String().substring(0, 10);
  String money(num v) => '${v.toDouble().toStringAsFixed(2)} د.أ';

  @override void initState() { super.initState(); load(); }
  @override void dispose() { tabs.dispose(); super.dispose(); }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    final db = await AppDatabase.instance.database;
    final f = day(from), t = day(to);
    final row = (await db.rawQuery('''
      SELECT
        COALESCE((SELECT SUM(total) FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ?),0) sales,
        COALESCE((SELECT COUNT(*) FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ?),0) invoices,
        COALESCE((SELECT SUM(total) FROM returns WHERE substr(created_at,1,10) BETWEEN ? AND ?),0) returns,
        COALESCE((SELECT SUM(si.quantity*si.unit_price) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ?),0) sold_lines,
        COALESCE((SELECT SUM(si.quantity*p.cost_price) FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ?),0) sales_cost,
        COALESCE((SELECT SUM(ri.quantity*p.cost_price) FROM return_items ri JOIN returns r ON r.id=ri.return_id JOIN products p ON p.id=ri.product_id WHERE substr(r.created_at,1,10) BETWEEN ? AND ?),0) return_cost,
        COALESCE((SELECT SUM(amount) FROM expenses WHERE substr(created_at,1,10) BETWEEN ? AND ?),0) expenses,
        COALESCE((SELECT SUM(total) FROM purchases WHERE substr(created_at,1,10) BETWEEN ? AND ?),0) purchases,
        COALESCE((SELECT SUM(total) FROM sales WHERE payment_method='نقدي' AND substr(created_at,1,10) BETWEEN ? AND ?),0) cash,
        COALESCE((SELECT SUM(total) FROM sales WHERE payment_method='آجل' AND substr(created_at,1,10) BETWEEN ? AND ?),0) credit,
        COALESCE((SELECT SUM(balance) FROM customers WHERE balance>0),0) customer_debt,
        COALESCE((SELECT SUM(balance) FROM suppliers WHERE balance>0),0) supplier_debt
    ''', [f,t,f,t,f,t,f,t,f,t,f,t,f,t,f,t,f,t,f,t,f,t])).first;

    final sales = (row['sales'] as num?)?.toDouble() ?? 0;
    final returns = (row['returns'] as num?)?.toDouble() ?? 0;
    final revenue = sales - returns;
    final cost = ((row['sales_cost'] as num?)?.toDouble() ?? 0) - ((row['return_cost'] as num?)?.toDouble() ?? 0);
    final gross = revenue - cost;
    final expenses = (row['expenses'] as num?)?.toDouble() ?? 0;

    final topProducts = await db.rawQuery('''
      SELECT si.product_name name,
             SUM(si.quantity) qty,
             SUM(si.total) gross,
             SUM(si.quantity*p.cost_price) cost
      FROM sale_items si
      JOIN sales s ON s.id=si.sale_id
      JOIN products p ON p.id=si.product_id
      WHERE substr(s.created_at,1,10) BETWEEN ? AND ?
      GROUP BY si.product_id, si.product_name
      ORDER BY gross DESC LIMIT 20
    ''', [f,t]);

    final cats = await db.rawQuery('''
      SELECT COALESCE(category,'غير مصنف') category, SUM(amount) total
      FROM expenses WHERE substr(created_at,1,10) BETWEEN ? AND ?
      GROUP BY category ORDER BY total DESC
    ''', [f,t]);

    final low = await AppDatabase.instance.lowStockProducts();
    if (!mounted) return;
    setState(() {
      totals = {
        'sales': sales, 'returns': returns, 'revenue': revenue, 'cost': cost,
        'gross': gross, 'expenses': expenses, 'net': gross-expenses,
        'purchases': (row['purchases'] as num?)?.toDouble() ?? 0,
        'cash': (row['cash'] as num?)?.toDouble() ?? 0,
        'credit': (row['credit'] as num?)?.toDouble() ?? 0,
        'invoices': (row['invoices'] as num?)?.toDouble() ?? 0,
        'customer_debt': (row['customer_debt'] as num?)?.toDouble() ?? 0,
        'supplier_debt': (row['supplier_debt'] as num?)?.toDouble() ?? 0,
      };
      products = topProducts;
      expenseCategories = cats;
      lowStock = low;
      loading = false;
    });
  }

  Future<void> pick(bool start) async {
    final initial = start ? from : to;
    final d = await showDatePicker(context: context, initialDate: initial, firstDate: DateTime(2020), lastDate: DateTime.now());
    if (d == null) return;
    setState(() { if (start) from=d; else to=d; if (from.isAfter(to)) { final x=from; from=to; to=x; } });
    await load();
  }

  Future<Map<String, dynamic>> _exportData() async => {
    'from': day(from), 'to': day(to), 'totals': totals, 'products': products,
    'expenses': expenseCategories, 'lowStock': lowStock,
  };

  Future<void> _exportPdf() async {
    final d = await _exportData();
    final bytes = await ReportExportService.buildPdf(
      from: d['from'], to: d['to'], totals: Map<String,double>.from(d['totals']),
      products: List<Map<String,dynamic>>.from(d['products']),
      expenseCategories: List<Map<String,dynamic>>.from(d['expenses']),
      lowStock: List<Map<String,dynamic>>.from(d['lowStock']),
    );
    await Printing.sharePdf(bytes: bytes, filename: 'Rose12_Report_${d['from']}_${d['to']}.pdf');
  }

  Future<void> _exportExcel() async {
    final d = await _exportData();
    final bytes = ReportExportService.buildExcel(
      from: d['from'], to: d['to'], totals: Map<String,double>.from(d['totals']),
      products: List<Map<String,dynamic>>.from(d['products']),
      expenseCategories: List<Map<String,dynamic>>.from(d['expenses']),
      lowStock: List<Map<String,dynamic>>.from(d['lowStock']),
    );
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/Rose12_Report_${d['from']}_${d['to']}.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([XFile(file.path, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')], text: 'تقرير Rose12 المالي');
  }

  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('مركز التقارير والإحصائيات'), actions: [
        PopupMenuButton<String>(
          tooltip: 'تصدير',
          onSelected: (v) { if (v == 'pdf') _exportPdf(); if (v == 'excel') _exportExcel(); },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'pdf', child: ListTile(leading: Icon(Icons.picture_as_pdf), title: Text('تصدير PDF'))),
            PopupMenuItem(value: 'excel', child: ListTile(leading: Icon(Icons.table_chart_outlined), title: Text('تصدير Excel'))),
          ],
          icon: const Icon(Icons.ios_share_outlined),
        ),
        IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
      ], bottom: TabBar(controller: tabs, isScrollable: true, tabs: const [Tab(text:'الملخص'),Tab(text:'المبيعات'),Tab(text:'المصروفات'),Tab(text:'المخزون')])),
      body: RefreshIndicator(onRefresh: load, child: TabBarView(controller: tabs, children: [_overview(), _sales(), _expenses(), _inventory()])),
    ),
  );

  Widget _range() => Card(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
    Expanded(child: OutlinedButton.icon(onPressed: ()=>pick(true), icon: const Icon(Icons.calendar_today), label: Text('من ${day(from)}'))),
    const SizedBox(width: 8),
    Expanded(child: OutlinedButton.icon(onPressed: ()=>pick(false), icon: const Icon(Icons.event), label: Text('إلى ${day(to)}'))),
  ])));

  Widget _overview() => ListView(padding: const EdgeInsets.all(14), children: [
    _range(), if (loading) const LinearProgressIndicator(),
    const SizedBox(height: 10),
    _grid([_metric('المبيعات', totals['sales']??0, Icons.trending_up), _metric('المرتجعات', totals['returns']??0, Icons.assignment_return), _metric('صافي المبيعات', totals['revenue']??0, Icons.receipt_long), _metric('التكلفة', totals['cost']??0, Icons.inventory_2_outlined), _metric('الربح الإجمالي', totals['gross']??0, Icons.account_balance_wallet_outlined), _metric('المصروفات', totals['expenses']??0, Icons.money_off), _metric('صافي الربح', totals['net']??0, Icons.show_chart), _metric('المشتريات', totals['purchases']??0, Icons.shopping_cart_outlined)]),
    const SizedBox(height: 14),
    _section('طرق الدفع', [_line('نقدي', money(totals['cash']??0), Icons.payments), _line('آجل', money(totals['credit']??0), Icons.schedule), _line('عدد الفواتير', '${(totals['invoices']??0).toInt()}', Icons.receipt_long)]),
    const SizedBox(height: 12),
    _section('الحسابات الحالية', [_line('ديون العملاء', money(totals['customer_debt']??0), Icons.people_alt_outlined), _line('مستحق للموردين', money(totals['supplier_debt']??0), Icons.local_shipping_outlined)]),
  ]);

  Widget _sales() => ListView(padding: const EdgeInsets.all(14), children: [
    _range(), if (loading) const LinearProgressIndicator(), const SizedBox(height: 10),
    const Text('أكثر المنتجات مبيعًا', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    if (products.isEmpty) const Card(child: ListTile(title: Text('لا توجد مبيعات في الفترة المحددة'))),
    ...products.asMap().entries.map((e) { final x=e.value; final gross=(x['gross'] as num?)?.toDouble()??0; final cost=(x['cost'] as num?)?.toDouble()??0; return Card(child: ListTile(leading: CircleAvatar(child: Text('${e.key+1}')), title: Text('${x['name']}'), subtitle: Text('الكمية: ${x['qty']}  •  ربح تقريبي: ${money(gross-cost)}'), trailing: Text(money(gross), style: const TextStyle(fontWeight: FontWeight.bold))); }),
  ]);

  Widget _expenses() => ListView(padding: const EdgeInsets.all(14), children: [
    _range(), if (loading) const LinearProgressIndicator(), const SizedBox(height: 10),
    Text('المصروفات حسب التصنيف', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    if (expenseCategories.isEmpty) const Card(child: ListTile(title: Text('لا توجد مصروفات في الفترة المحددة'))),
    ...expenseCategories.map((x)=>Card(child: ListTile(leading: const Icon(Icons.category_outlined), title: Text('${x['category']}'), trailing: Text(money((x['total'] as num?)??0), style: const TextStyle(fontWeight: FontWeight.bold))))),
  ]);

  Widget _inventory() => ListView(padding: const EdgeInsets.all(14), children: [
    Card(child: ListTile(leading: const Icon(Icons.warning_amber_outlined), title: const Text('تنبيهات المخزون'), subtitle: Text('عدد المنتجات منخفضة المخزون: ${lowStock.length}'))),
    const SizedBox(height: 8),
    if (lowStock.isEmpty) const Card(child: ListTile(title: Text('المخزون ضمن الحدود المحددة'))),
    ...lowStock.map((x)=>Card(child: ListTile(title: Text('${x['name']}'), subtitle: Text('الحد الأدنى: ${x['min_stock']} ${x['unit']}'), trailing: Text('${x['quantity']} ${x['unit']}', style: const TextStyle(fontWeight: FontWeight.bold))))),
  ]);

  Widget _grid(List<Widget> children) => GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.65, children: children);
  Widget _metric(String title, double value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF2C668F)), const Spacer(), Text(money(value), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), Text(title, style: const TextStyle(color: Colors.grey))])));
  Widget _section(String title, List<Widget> rows) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 6), ...rows])));
  Widget _line(String title, String value, IconData icon) => ListTile(dense: true, leading: Icon(icon), title: Text(title), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold)));
}
