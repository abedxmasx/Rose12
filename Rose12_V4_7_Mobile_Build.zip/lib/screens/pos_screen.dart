import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../database/app_database.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});
  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> customers = [];
  final cart = <Map<String, dynamic>>[];
  final search = TextEditingController();
  final discountController = TextEditingController(text: '0');
  String payment = 'نقدي';
  Map<String, dynamic>? selectedCustomer;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await AppDatabase.instance.products();
    final c = await AppDatabase.instance.customers();
    if (mounted) setState(() { products = p; customers = c; });
  }

  @override
  void dispose() { search.dispose(); discountController.dispose(); super.dispose(); }

  double get subtotal => cart.fold(0, (sum, x) => sum + (x['price'] as double) * (x['qty'] as int));
  double get discount {
    final v = double.tryParse(discountController.text.replaceAll(',', '.')) ?? 0;
    return v.clamp(0, subtotal).toDouble();
  }
  double get total => subtotal - discount;

  void _add(Map<String, dynamic> p) {
    final stock = (p['quantity'] as num?)?.toDouble() ?? 0;
    final index = cart.indexWhere((x) => x['product_id'] == p['id']);
    final current = index >= 0 ? (cart[index]['qty'] as int) : 0;
    if (stock <= current) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('الكمية المتوفرة من ${p['name']} هي ${stock.toStringAsFixed(0)}')));
      return;
    }
    setState(() {
      if (index >= 0) cart[index]['qty'] = current + 1;
      else cart.add({'product_id': p['id'], 'name': p['name'], 'price': (p['sale_price'] as num).toDouble(), 'qty': 1, 'stock': stock});
    });
  }

  void _changeQty(int index, int delta) {
    final item = cart[index];
    final next = (item['qty'] as int) + delta;
    final stock = (item['stock'] as num).toDouble();
    if (next <= 0) { setState(() => cart.removeAt(index)); return; }
    if (next > stock) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا يمكن بيع كمية أكبر من المخزون المتوفر'))); return; }
    setState(() => item['qty'] = next);
  }

  Future<void> _completeSale() async {
    if (cart.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف منتجاً واحداً على الأقل'))); return; }
    if (payment == 'آجل' && selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اختر العميل عند البيع الآجل'))); return;
    }
    final invoice = await AppDatabase.instance.nextInvoiceNumber();
    await AppDatabase.instance.createSale(
      localUuid: const Uuid().v4(), invoiceNumber: invoice, items: cart,
      subtotal: subtotal, discount: discount, total: total,
      paidAmount: payment == 'آجل' ? 0 : total, paymentMethod: payment,
      customerId: selectedCustomer?['id'] as int?, customerName: selectedCustomer?['name'] as String?,
    );
    if (!mounted) return;
    setState(() { cart.clear(); discountController.text = '0'; selectedCustomer = null; });
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('تم حفظ الفاتورة ✓'),
      content: Text('رقم الفاتورة: $invoice\n\nالإجمالي: ${total.toStringAsFixed(2)} د.أ\nتم حفظها محلياً، وستدخل قائمة الترحيل عند توفر الإنترنت.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('موافق'))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final q = search.text.trim().toLowerCase();
    final shown = products.where((p) => q.isEmpty || (p['name'] as String).toLowerCase().contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('نقطة البيع')),
      body: Directionality(textDirection: TextDirection.rtl, child: Column(children: [
        Padding(padding: const EdgeInsets.all(14), child: TextField(controller: search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'ابحث عن اسم المنتج', prefixIcon: Icon(Icons.search)))),
        SizedBox(height: 115, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 14), scrollDirection: Axis.horizontal, itemCount: shown.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) {
          final p = shown[i];
          return SizedBox(width: 150, child: Card(child: InkWell(onTap: () => _add(p), borderRadius: BorderRadius.circular(18), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(p['name'], maxLines: 1, overflow: TextOverflow.ellipsis), const SizedBox(height: 5), Text('${(p['sale_price'] as num).toStringAsFixed(2)} د.أ'), Text('المتوفر: ${(p['quantity'] as num).toStringAsFixed(0)}', style: const TextStyle(fontSize: 11, color: Colors.grey)), const Text('اضغط للإضافة', style: TextStyle(fontSize: 11, color: Colors.grey))]))));
        })),
        const Divider(),
        Expanded(child: cart.isEmpty ? const Center(child: Text('السلة فارغة')) : ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 14), itemCount: cart.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
          final x = cart[i];
          return Card(child: ListTile(title: Text(x['name']), subtitle: Text('${(x['price'] as double).toStringAsFixed(2)} د.أ × ${x['qty']}'), leading: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => _changeQty(i, -1), icon: const Icon(Icons.remove_circle_outline)), Text('${x['qty']}'), IconButton(onPressed: () => _changeQty(i, 1), icon: const Icon(Icons.add_circle_outline))]), trailing: IconButton(onPressed: () => setState(() => cart.removeAt(i)), icon: const Icon(Icons.delete_outline)));
        })),
        Container(padding: const EdgeInsets.fromLTRB(16, 10, 16, 16), decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))), child: Column(children: [
          Row(children: [const Expanded(child: Text('العميل (اختياري للنقدي)')), Expanded(child: DropdownButton<Map<String,dynamic>>(isExpanded: true, value: selectedCustomer, hint: const Text('بدون عميل'), items: [const DropdownMenuItem<Map<String,dynamic>>(value: null, child: Text('بدون عميل')), ...customers.map((c) => DropdownMenuItem(value: c, child: Text('${c['name']}')))], onChanged: (v) => setState(() => selectedCustomer = v)))]),
          const SizedBox(height: 6),
          Row(children: [const Expanded(child: Text('الخصم')), SizedBox(width: 130, child: TextField(controller: discountController, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: const InputDecoration(suffixText: 'د.أ')))]),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الإجمالي الفرعي'), Text('${subtotal.toStringAsFixed(2)} د.أ')]),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الخصم'), Text('- ${discount.toStringAsFixed(2)} د.أ')]),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الإجمالي', style: TextStyle(fontWeight: FontWeight.bold)), Text('${total.toStringAsFixed(2)} د.أ', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          Row(children: ['نقدي', 'آجل'].map((m) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: ChoiceChip(label: Text(m), selected: payment == m, onSelected: (_) => setState(() => payment = m)))).toList()),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: _completeSale, icon: const Icon(Icons.check_circle_outline), label: const Text('إتمام البيع وحفظ الفاتورة'))),
        ])),
      ])),
    );
  }
}
