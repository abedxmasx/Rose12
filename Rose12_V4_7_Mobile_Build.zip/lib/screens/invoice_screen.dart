import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import '../database/app_database.dart';
import '../services/invoice_service.dart';

class InvoiceScreen extends StatefulWidget {
  final Map<String, dynamic> sale;
  const InvoiceScreen({super.key, required this.sale});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('sale_items', where: 'sale_id = ?', whereArgs: [widget.sale['id']]);
    if (mounted) setState(() { items = rows; loading = false; });
  }

  Future<Uint8List> _pdf({PdfPageFormat format = PdfPageFormat.a4}) {
    return InvoiceService.buildPdf(sale: widget.sale, items: items, format: format);
  }

  Future<void> _print() async {
    await Printing.layoutPdf(onLayout: (_) => _pdf());
  }

  Future<void> _share() async {
    final bytes = await _pdf();
    await Printing.sharePdf(bytes: bytes, filename: 'Rose12_${widget.sale['invoice_number']}.pdf');
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.sale;
    final subtotal = (s['subtotal'] as num?)?.toDouble() ?? 0;
    final discount = (s['discount'] as num?)?.toDouble() ?? 0;
    final total = (s['total'] as num?)?.toDouble() ?? 0;
    return Scaffold(
      appBar: AppBar(
        title: Text('فاتورة ${s['invoice_number']}'),
        actions: [
          IconButton(tooltip: 'مشاركة PDF', onPressed: loading ? null : _share, icon: const Icon(Icons.share_outlined)),
          IconButton(tooltip: 'طباعة', onPressed: loading ? null : _print, icon: const Icon(Icons.print_outlined)),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(children: [
                        Image.asset('assets/rose12_logo.png', height: 70, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
                        const Text('فاتورة مبيعات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 10),
                        Text('رقم الفاتورة: ${s['invoice_number']}'),
                        Text('التاريخ: ${s['created_at']}'),
                        if ('${s['customer_name'] ?? ''}'.isNotEmpty) Text('العميل: ${s['customer_name']}'),
                        Text('طريقة الدفع: ${s['payment_method']}'),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Card(
                    child: Column(children: [
                      const ListTile(title: Text('المنتجات', style: TextStyle(fontWeight: FontWeight.bold))),
                      ...items.map((x) => ListTile(
                        title: Text('${x['product_name']}'),
                        subtitle: Text('${x['quantity']} × ${((x['unit_price'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ'),
                        trailing: Text('${((x['total'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} د.أ'),
                      )),
                    ]),
                  ),
                  Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
                    _row('المجموع الفرعي', subtotal),
                    _row('الخصم', -discount),
                    const Divider(),
                    _row('الإجمالي', total, bold: true),
                  ]))),
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: _share, icon: const Icon(Icons.share), label: const Text('مشاركة PDF'))),
                    const SizedBox(width: 10),
                    Expanded(child: FilledButton.icon(onPressed: _print, icon: const Icon(Icons.print), label: const Text('طباعة'))),
                  ]),
                ],
              ),
      ),
    );
  }

  Widget _row(String label, double value, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 19 : 14);
    return Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [
      Expanded(child: Text('${value < 0 ? '- ' : ''}${value.abs().toStringAsFixed(2)} د.أ', style: style)),
      Text(label, style: style),
    ]));
  }
}
